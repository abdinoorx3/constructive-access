CONSTRUCTIVE INFERENCE FOR PHYSICAL DIAGNOSTICS
Abdinoor / 2D Labs / 12 October 2026

Start with discovery_program/application_audit/manuscript/physical_diagnostics.pdf.
The application map is discovery_program/application_audit/APPLICATIONS.txt.

This standalone application release contains all new code and results, the
unchanged companion files required by its quantum example, and the complete
previous research archive in preserved/. That archive in turn contains all
four earlier research releases. No old release has been overwritten.

To reproduce, from this extracted top directory:
  cd discovery_program/application_audit
  python -m pip install -r requirements.txt
  python verify.py

Use --skip-pdf if LaTeX is unavailable; a finished PDF is included. Dependency
installation may require internet access. The research commands require none.

Verify MANIFEST.sha256 before rerunning. Generated outputs, logs, timestamps
and PDF metadata are rewritten by reproduction. Exact scientific assertions
are checked in executable modules; timing and PDF bytes may vary by environment.
The immutable dependencies and preserved archive are verified before and after
execution. Checksums identify bytes; they are not scientific endorsements.

The worked models and proofs received separate internal review and reproducible
checks. Historical priority, external peer review, actual quantum/hardware or
biological measurements, and practical advantage remain separately identified
evidence tasks. See CLAIMS.json and the application map for precise scope.
