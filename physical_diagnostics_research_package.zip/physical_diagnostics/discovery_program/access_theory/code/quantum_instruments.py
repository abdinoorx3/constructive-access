"""Kraus-derived exact quantum examples for the common access checker.

Finite classical-feedback instrument library only. No quantum computational
advantage, unrestricted quantum-control or energy-cost claim is made.
"""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp


I = sp.eye(2)
X = sp.Matrix([[0, 1], [1, 0]])
Y = sp.Matrix([[0, -sp.I], [sp.I, 0]])
Z = sp.diag(1, -1)
PAULI = [I, X, Y, Z]
P0 = (I+Z)/2
P1 = (I-Z)/2
RHO = P0
TERMINAL = sp.Matrix([2, 0, 0, 0])
INITIAL = sp.Matrix([[sp.trace(b*RHO)/2 for b in PAULI]])
RX_PLUS = (I-sp.I*X)/sp.sqrt(2)
PHASE_Z = sp.diag(1, sp.I)


def simplify(matrix):
    return matrix.applyfunc(sp.simplify)


def channel(kraus, matrix):
    return simplify(sum((k*matrix*k.H for k in kraus), sp.zeros(2)))


def transfer(kraus):
    # rho = sum_mu x_mu B_mu; x'_nu = sum_mu x_mu M_mu,nu.
    matrix = sp.Matrix([[sp.simplify(sp.trace(bn*channel(kraus, bm))/2)
                         for bn in PAULI] for bm in PAULI])
    assert all(value.is_Rational for value in matrix)
    for b in PAULI:
        assert channel(kraus, b) == channel(kraus, b).H
    return matrix


def instrument_library(sign, rotation=False):
    unknown = (I-sign*sp.I*X)/sp.sqrt(2)
    actions = {
        "evolve": {"done": [unknown]},
        "phase_z": {"done": [PHASE_Z]},
        "measure_z": {"0": [P0], "1": [P1]},
        "dephase_z": {"done": [P0, P1]},
    }
    if rotation:
        actions["rotate_x"] = {"done": [RX_PLUS]}
    kernels = {}
    for action, outcomes in actions.items():
        completeness = sum((k.H*k for values in outcomes.values() for k in values), sp.zeros(2))
        assert simplify(completeness-I) == sp.zeros(2)
        for outcome, kraus in outcomes.items():
            kernels[action, outcome] = transfer(kraus)
        assert simplify(sum((kernels[action, y] for y in outcomes), sp.zeros(4))*TERMINAL-TERMINAL) == sp.zeros(4, 1)
    return actions, kernels


def probability(kernels, word):
    state = INITIAL
    for letter in word:
        state = state*kernels[letter]
    return sp.factor((state*TERMINAL)[0])


def kraus_probability(actions, word):
    state = RHO
    for action, outcome in word:
        state = channel(actions[action][outcome], state)
    return sp.simplify(sp.trace(state))


def own_span_certificate(kernels0, kernels1):
    """Independent small exact closure, separate from accesskit implementation."""
    paired = {letter: sp.diag(kernels0[letter], kernels1[letter]) for letter in sorted(kernels0)}
    terminal = TERMINAL.col_join(TERMINAL)
    initial = INITIAL.row_join(-INITIAL)
    basis = [terminal]
    words = [()]
    cursor = 0
    violations = []
    while cursor < len(basis):
        gap = sp.factor((initial*basis[cursor])[0])
        if gap:
            violations.append({"word": words[cursor], "gap": str(gap)})
        for letter, matrix in paired.items():
            new = matrix*basis[cursor]
            if sp.Matrix.hstack(*basis, new).rank() > len(basis):
                basis.append(new)
                words.append((letter,)+words[cursor])
        cursor += 1
    bm = sp.Matrix.hstack(*basis)
    assert all(bm.row_join(matrix*bm).rank() == bm.cols for matrix in paired.values())
    return {"rank": len(basis), "basis_words": words,
            "annihilation_values": [str(value) for value in initial*bm],
            "closed_under_every_letter": True, "violations": violations}


def symmetry_certificate(actions0, actions1):
    for action, outcomes in actions0.items():
        for outcome in outcomes:
            for b in PAULI:
                lhs = channel(actions1[action][outcome], Z*b*Z)
                rhs = Z*channel(actions0[action][outcome], b)*Z
                assert simplify(lhs-rhs) == sp.zeros(2)
    assert Z*RHO*Z == RHO


def run():
    from accesskit import LinearRepresentation, compare_linear_representations, verify_access_result, experiment_law

    blind0, kblind0 = instrument_library(1, False)
    blind1, kblind1 = instrument_library(-1, False)
    active0, kactive0 = instrument_library(1, True)
    active1, kactive1 = instrument_library(-1, True)
    symmetry_certificate(blind0, blind1)
    blind_certificate = own_span_certificate(kblind0, kblind1)
    assert not blind_certificate["violations"]
    active_certificate = own_span_certificate(kactive0, kactive1)
    assert active_certificate["violations"]

    blind_reps = (
        LinearRepresentation(INITIAL, kblind0, TERMINAL, name="qubit_plus_blind"),
        LinearRepresentation(INITIAL, kblind1, TERMINAL, name="qubit_minus_blind"),
    )
    active_reps = (
        LinearRepresentation(INITIAL, kactive0, TERMINAL, name="qubit_plus_rotation"),
        LinearRepresentation(INITIAL, kactive1, TERMINAL, name="qubit_minus_rotation"),
    )
    blind_result = compare_linear_representations(*blind_reps)
    active_result = compare_linear_representations(*active_reps)
    assert verify_access_result(*blind_reps, blind_result)
    assert verify_access_result(*active_reps, active_result)
    assert blind_result.equivalent
    assert not active_result.equivalent
    assert active_result.witness is not None
    witness = tuple(active_result.witness)
    assert probability(kactive0, witness) != probability(kactive1, witness)
    assert probability(kactive0, witness) == kraus_probability(active0, witness)
    assert probability(kactive1, witness) == kraus_probability(active1, witness)
    fixed_actions = tuple(action for action, outcome in witness)
    witness_laws = [experiment_law(rep, fixed_actions) for rep in active_reps]
    exact_tv = sp.factor(sum(abs(witness_laws[0][word]-witness_laws[1][word])
                             for word in witness_laws[0])/2)
    assert exact_tv == 1

    derived_word = (("evolve", "done"), ("rotate_x", "done"), ("measure_z", "0"))
    assert probability(kactive0, derived_word) == 0
    assert probability(kactive1, derived_word) == 1
    for actions, kernels in [(active0, kactive0), (active1, kactive1)]:
        assert kraus_probability(actions, derived_word) == probability(kernels, derived_word)

    coherent = (("evolve", "done"), ("evolve", "done"), ("measure_z", "0"))
    dephased = (("evolve", "done"), ("dephase_z", "done"), ("evolve", "done"), ("measure_z", "0"))
    for kernels in [kblind0, kblind1]:
        assert probability(kernels, coherent) == 0
        assert probability(kernels, dephased) == sp.Rational(1, 2)

    # Outcome-only calibration can miss maximal postmeasurement disturbance.
    reset0 = [sp.Matrix([[1, 0], [0, 0]]), sp.Matrix([[0, 1], [0, 0]])]
    reset1 = [sp.Matrix([[0, 0], [1, 0]]), sp.Matrix([[0, 0], [0, 1]])]
    for kk in [reset0, reset1]:
        assert sum((k.H*k for k in kk), sp.zeros(2)) == I
    assert sp.trace(channel(reset0, RHO)) == sp.trace(channel(reset1, RHO)) == 1
    assert sp.trace(P0*channel(reset0, RHO)) == 1
    assert sp.trace(P0*channel(reset1, RHO)) == 0

    result = {
        "status": "exact model calculations; no novelty, device validation or quantum advantage claim",
        "dimension": {"hilbert_each": 2, "hermitian_each": 4, "paired": 8, "unconstrained_witness_length_bound": 7},
        "coordinates": "rho=sum x_mu Pauli_mu, x_mu=Tr(Pauli_mu rho)/2; terminal=(2,0,0,0)",
        "all_action_instruments_complete_from_kraus": True,
        "all_transfer_entries_rational": True,
        "blind_kernels_plus": {str(letter): [[str(v) for v in row] for row in m.tolist()] for letter, m in kblind0.items()},
        "blind_kernels_minus": {str(letter): [[str(v) for v in row] for row in m.tolist()] for letter, m in kblind1.items()},
        "known_rotation_transfer": [[str(v) for v in row] for row in kactive0["rotate_x", "done"].tolist()],
        "blind_covariance_under_Z_verified": True,
        "blind_independent_span_certificate": blind_certificate,
        "active_independent_span_certificate": active_certificate,
        "common_checker_blind": bool(blind_result.equivalent),
        "common_checker_active": bool(active_result.equivalent),
        "common_certificates_independently_verified": True,
        "common_checker_witness": witness,
        "common_checker_witness_probabilities": [str(probability(kactive0, witness)), str(probability(kactive1, witness))],
        "witness_complete_transcript_laws": [{str(word): str(p) for word, p in law.items()} for law in witness_laws],
        "witness_complete_transcript_TV": str(exact_tv),
        "independently_derived_perfect_word": derived_word,
        "independently_derived_probabilities": ["0", "1"],
        "measurement_backaction": {"coherent_word": coherent, "coherent_probability0": "0", "dephased_word": dephased, "dephased_probability0": "1/2"},
        "outcome_only_calibration_failure": "both resets always output done, but next Z readout has probabilities 1 and 0; half-diamond distance is 1",
        "sympy_version": sp.__version__,
        "precision": "exact symbolic Kraus algebra and rational linear algebra",
        "randomness": "none",
        "scope": ["fixed finite listed instrument library", "classical adaptive policies included", "no unlisted ancilla/coherent feedback", "ideal noiseless example; calibration robustness separate", "Clifford example is classically efficiently simulable", "no energy expenditure inferred from a Kraus map"]
    }
    destination = Path(__file__).resolve().parents[1]/"results"/"quantum_instruments.json"
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
