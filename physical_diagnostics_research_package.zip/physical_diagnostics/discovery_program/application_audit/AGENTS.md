# Constructive inference application audit

Abdinoor / 2D Labs / 12 October 2026

Inherit ../AGENTS.md. Preserve every earlier release including hardening/.
The supplied analysis identifies four application targets:
AI hardware energy, scalable quantum characterization, metabolic flux,
and biological quantum sensing. These differ from the four validation gates.

Goal: turn the strongest defensible application claims into exact, reusable
worked models, with explicit transfer assumptions and counterexamples.
Distinguish target-specific identification from total information recovery,
nonzero contrast from reliable classification, generic cost from calibrated
energy, and internal computation from external measured evidence.

Root owns integrated manuscript, general statements, README, ledger and logs.
Agents own named research/code/results files. No old file changes, outreach,
publication, purchases or physical experiments. Record sources precisely.
The pasted source lost several mathematical expressions during rendering;
do not reconstruct those as quotations or treat missing formulas as proved.

Scientific loop: extract claim; locate exact supporting theorem/prior art;
construct a failure case; derive the surviving operational statement; compute
an exact worked case and strong baseline; independently review; retain or
narrow with a recorded scope. No promise of a background research service.
