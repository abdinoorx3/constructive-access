#!/usr/bin/env python3
"""Reproduce the application release and verify its immutable dependencies."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
DEPENDENCIES = {
 "discovery_program/manuscript/quantum_access.tex":"5453ff35305d7178880e077d0bd5e11f0cf248ed57ac716e019fca4e831fc83b",
 "discovery_program/access_theory/code/quantum_instruments.py":"0a0b2327d1df8c94794f2b5099fc288e4b1be07971da8f52a91af6a0ee0eb191",
 "discovery_program/access_theory/code/accesskit.py":"8740d34286b7b471d304c9b214ae16ce030252abb81ac27d6d7da2a5cad968e9",
}
PRIOR_ARCHIVE_SHA256="b3764a39b5ecac30d5a1eecb2301bbbba096fe51be77e7a4c34363cac47bb8eb"
MODULES=("intervention_criterion","metabolic_flux","quantum_scaling",
         "nv_sensing","energy_identifiability","transfer_obstructions")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sources():
    files = list((ROOT/"code").glob("*.py"))+list(ROOT.glob("*.py"))
    files += list((ROOT/"manuscript").glob("*.tex"))
    files += list((ROOT/"research").glob("*.txt"))
    files += [ROOT/name for name in ("README.txt","APPLICATIONS.txt","CLAIMS.json","requirements.txt")]
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}

def dependencies():
    checks={name:{"expected":expected,
                  "actual":sha(WORKSPACE/name) if (WORKSPACE/name).is_file() else None}
            for name,expected in DEPENDENCIES.items()}
    candidates=[WORKSPACE/"preserved/hardened_access_research_package.zip",
                WORKSPACE/"hardened_access_research_package.zip"]
    archive=next((p for p in candidates if p.is_file()),None)
    archive_digest=sha(archive) if archive is not None else None
    return {"files":checks,"archive_path":str(archive) if archive else None,
            "archive_sha256":archive_digest,"expected_archive_sha256":PRIOR_ARCHIVE_SHA256,
            "passed":all(x["actual"]==x["expected"] for x in checks.values())
                     and archive_digest==PRIOR_ARCHIVE_SHA256}

def run(name,argv,cwd=ROOT):
    env=dict(os.environ)
    env.pop("PYTHONOPTIMIZE",None)
    env["MPLBACKEND"]="Agg"
    start=time.monotonic()
    result=subprocess.run(argv,cwd=cwd,env=env,text=True,
                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=ROOT/"logs"/f"verify_{name}.log"
    log.write_text(result.stdout)
    print(f"{name}: {'PASS' if result.returncode==0 else 'FAIL'}",flush=True)
    return {"name":name,"argv":argv,"exit_code":result.returncode,
            "elapsed_seconds":round(time.monotonic()-start,6),
            "log":str(log.relative_to(ROOT)),"log_sha256":sha(log)}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-pdf",action="store_true")
    args=parser.parse_args()
    if sys.flags.optimize:
        parser.error("Verification requires Python assertions; do not use -O or PYTHONOPTIMIZE.")
    before=sources()
    deps_before=dependencies()
    if not deps_before["passed"]:
        parser.error("Immutable dependency/archive checks failed. Extract the complete application package.")
    python=sys.executable
    jobs=[(name,[python,f"code/{name}.py"]) for name in MODULES]
    with ThreadPoolExecutor(max_workers=6) as pool:
        commands=list(pool.map(lambda job:run(*job),jobs))
    if all(c["exit_code"]==0 for c in commands):
        commands.append(run("cross_domain_review",[python,"code/cross_domain_review.py"]))
    if all(c["exit_code"]==0 for c in commands):
        commands.append(run("make_figure",[python,"code/make_figure.py"]))
    if not args.skip_pdf and all(c["exit_code"]==0 for c in commands):
        for n in (1,2):
            commands.append(run(f"pdflatex_{n}",["pdflatex","-interaction=nonstopmode",
                                "-halt-on-error","physical_diagnostics.tex"],ROOT/"manuscript"))
    after=sources()
    deps_after=dependencies()
    required=[ROOT/"results"/f"{name}.json" for name in MODULES+("cross_domain_review","make_figure")]
    required += [ROOT/"manuscript/application_results.pdf",ROOT/"manuscript/application_results.png"]
    if not args.skip_pdf:
        required += [ROOT/"manuscript/physical_diagnostics.pdf",ROOT/"manuscript/physical_diagnostics.log"]
    missing=[str(p.relative_to(ROOT)) for p in required if not p.is_file()]
    typesetting=[]
    if not args.skip_pdf and (ROOT/"manuscript/physical_diagnostics.log").is_file():
        typesetting=[line for line in (ROOT/"manuscript/physical_diagnostics.log").read_text().splitlines()
                     if any(t in line for t in ("Overfull ","undefined references","undefined citations","LaTeX Error"))]
    passed=(len(commands)==(8 if args.skip_pdf else 10)
            and all(c["exit_code"]==0 for c in commands)
            and before==after and deps_before==deps_after
            and not missing and not typesetting)
    report={"recorded_utc":datetime.now(timezone.utc).isoformat(),
            "status":"passed" if passed else "failed",
            "scope":"Internal exact/synthetic application reproduction; no new physical data or external peer review",
            "python":platform.python_version(),
            "packages":{n:importlib.metadata.version(n) for n in ("sympy","numpy","scipy","matplotlib","mpmath")},
            "source_unchanged":before==after,"source_sha256":before,
            "immutable_dependencies":deps_after,"dependencies_unchanged":deps_before==deps_after,
            "commands":commands,"required_outputs_missing":missing,
            "typesetting_problems":typesetting,
            "output_sha256":{str(p.relative_to(ROOT)):sha(p) for p in required if p.is_file()}}
    (ROOT/"results/verification.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"status":report["status"],"commands":len(commands),
                      "source_unchanged":before==after,"dependencies_unchanged":deps_before==deps_after}))
    return 0 if passed else 1

if __name__=="__main__":
    raise SystemExit(main())
