CONSTRUCTIVE INFERENCE FOR PHYSICAL DIAGNOSTICS
Four Applications and Their Access Requirements
Abdinoor / 2D Labs / 12 October 2026

Read manuscript/physical_diagnostics.pdf and APPLICATIONS.txt first.
This release evaluates the actual four application targets in the supplied
analysis and develops reproducible, scoped application models. The
previous release's four validation gates remain a separate evidence checklist.

Concrete results

1. A linear target is identifiable when it lies in the row space of the known
   intervention response matrix, under explicit experimental-access premises.
   Exact primal/dual certificates give the sharp global deterministic error
   over a full positive parameter class and Cartesian response-error box.
   Weak selectivity can make an identifiable target practically unstable.

2. A two-channel chemical model is completely ambiguous under passive state
   trajectories, yet a calibrated reaction-selective perturbation reconstructs
   its native rates. A continuous calibration box certifies native current
   [193/204,207/196] and a conservative entropy-production interval. The model
   explicitly accounts for changed physiology and unknown selectivity.

3. A coherent-component quantum channel and its stochastic Pauli counterpart
   have equal average fidelity and one-step population statistics. A calibrated
   phase-sensitive protocol distinguishes them. In the stated finite depth
   menu, sufficient unknown-channel calls fall from 590 to 240. Those counts
   exclude separately recorded preparation/readout/control costs; they are not
   measured energy or a universal optimal sampling bound.

4. A finite Ramsey model includes dephasing, readout bias and time overhead.
   Exact Bayes optimization matches the best fixed design at budget 12. At
   budget 15, feedback improves absolute decision error by 0.00192. A local
   Fisher-information heuristic answers a different question and can miss sign.

5. A hidden fueled cycle yields identical accessible laws under all permitted
   adaptive interventions while its entropy production varies without bound
   absent rate/fuel limits. Total hardware energy therefore needs a separate
   physical account. The framework does not imply Landauer-limit AI hardware.

6. An exact four-state example refutes the extension of stationary singleton
   reversibility to every coarse binary detector. A finite-lag rational bound
   and a singleton negative control accompany the Taylor calculation.

These are mathematical application models, not new laboratory measurements.
Established identification, optimal recovery, thermodynamic inference, quantum
benchmarking and adaptive sensing are credited. Priority and broad application
success remain open. CLAIMS.json records the scope of each result.

Reproduction

Tested with Python 3.12.14 and requirements.txt. The complete archive includes
the three unchanged companion files needed by the quantum example in their
original relative locations, plus the previous complete hardening archive in
preserved/. No restoration or network access is needed after dependencies are
installed. The verifier checks those immutable bytes before and after running.

From this directory:
  python -m pip install -r requirements.txt
  python verify.py

If pdflatex is unavailable:
  python verify.py --skip-pdf

The full verifier runs six application modules, the independent cross-domain
review, the figure generator, and two LaTeX passes: ten commands in total.
Each command has a retained log. It rewrites generated results and PDFs, never
the preserved companion source. Do not disable Python assertions with -O.
Installing dependencies may require internet access; the science commands do not.

Entry points
  code/intervention_criterion.py   Exact identification/minimax certificates
  code/metabolic_flux.py          Channel reconstruction and calibration boxes
  code/quantum_scaling.py         Coherence diagnosis, depth and scaling checks
  code/nv_sensing.py              Exact policy synthesis and exhaustive baselines
  code/energy_identifiability.py  Hidden energy and all-record equivalence
  code/transfer_obstructions.py   Binary aggregate and other scope controls
  code/cross_domain_review.py     Independent calculations, no producer imports

Results include rational values, the complete sensing policy trees, primary
input parameters, physical premises and negative controls. All core examples
are deterministic; numerical matrix-exponential spot checks support separate
symbolic identities and do not replace them. One-time run timings and PDF bytes
are environment-dependent and are not scientific claims.

Evidence and source map
  manuscript/       Nine-page integrated paper, source and data-generated figure
  research/         Derivations, primary-source comparisons and internal reviews
  results/          Generated evidence and authoritative verification record
  CLAIMS.json       Scoped status and unresolved experimental requirements
  APPLICATIONS.txt  Four-target application and validation map
  logs/events.jsonl Actual milestones and decisions
  AGENTS.md         Research rules and authorized scope
  SWARM.md          Assignments and resumable checkpoint

The user-supplied text is now evaluated directly. research/input_scope.txt
indexes selected original assertions and all eight supplied references;
research/citation_audit.txt checks their support. Several displayed equations
were lost in the paste, so exact formulas are taken from the preserved original
manuscripts or derived explicitly. No inaccessible formula was invented.

Check the distributed MANIFEST.sha256 BEFORE rerunning: reproduction replaces
generated outputs, timestamps and rendering metadata. The paper's scientific
claims are tested by the commands, not by demanding byte-identical PDFs.
The preserved/hardened_access_research_package.zip contains the complete prior
release and all four earlier research archives unchanged.

Internal reviews are collaborating-agent checks; they are not external peer
review or independent experimental replication. A successful application must
still validate its physical model, calibration, target and matched-resource
advantage with independent evidence.
