#!/usr/bin/env python3
"""Independent exact counterexamples to overbroad application translations.

All models are mathematical constructions. No measured data, hardware energy,
historical novelty, or general computational speedup is inferred.
"""
from __future__ import annotations

from collections import deque
from fractions import Fraction as F
from math import comb, factorial
from pathlib import Path
import json


def identity(n):
    return [[F(int(i == j)) for j in range(n)] for i in range(n)]


def matmul(a, b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def matvec(a, v):
    return [sum((x*y for x, y in zip(row, v)), F(0)) for row in a]


def rowmat(v, a):
    return [sum((v[i]*a[i][j] for i in range(len(v))), F(0)) for j in range(len(a[0]))]


def diagonal(v):
    return [[F(x) if i == j else F(0) for j in range(len(v))] for i, x in enumerate(v)]


def dot(x, y):
    return sum((a*b for a, b in zip(x, y)), F(0))


def check_generator(q, pi):
    assert len(q) == len(pi)
    assert all(sum(row) == 0 for row in q)
    assert all(q[i][j] >= 0 for i in range(len(q)) for j in range(len(q)) if i != j)
    assert sum(pi) == 1 and min(pi) > 0
    assert rowmat(pi, q) == [0]*len(pi)


def adjoint(q, pi):
    return [[pi[j]*q[j][i]/pi[i] for j in range(len(q))] for i in range(len(q))]


def jet(pi, d, q, m, n):
    row = rowmat(pi, d)
    for _ in range(m):
        row = rowmat(row, q)
    row = rowmat(row, d)
    for _ in range(n):
        row = rowmat(row, q)
    return sum(rowmat(row, d))


def exact_closure(q, pi, sensor):
    """Continuous-generator/projector series equality against stationary reverse.

    The generator letter encodes Taylor derivatives, not a stochastic one-step
    action. Analytic semigroups transfer all-word equality to continuous times.
    """
    n = len(q)
    qr = adjoint(q, pi)
    d = diagonal(sensor)
    def block(a,b):
        return [row+[F(0)]*n for row in a]+[[F(0)]*n+row for row in b]
    letters = {"Q": block(q,qr), "D": block(d,d)}
    alpha = pi+[-x for x in pi]
    beta = [F(1)]*(2*n)
    queue = deque([(beta, ())])
    echelon = []
    accepted = []
    witnesses = []
    while queue:
        original, word = queue.popleft()
        v = original[:]
        for pivot, row in echelon:
            coefficient = v[pivot]
            v = [x-coefficient*y for x,y in zip(v,row)]
        pivot = next((i for i,x in enumerate(v) if x), None)
        if pivot is None:
            continue
        denominator = v[pivot]
        echelon.append((pivot,[x/denominator for x in v]))
        accepted.append((original,word))
        contrast = dot(alpha,original)
        if contrast:
            witnesses.append({"word": list(word), "contrast": str(contrast)})
        for label,matrix in letters.items():
            queue.append((matvec(matrix,original),(label,)+word))
    assert len(accepted) <= 2*n
    return {"equivalent": not witnesses, "rank":len(accepted),
            "nonzero_actual_word_effects": witnesses,
            "proof_scope":"Exact finite generator/projector closure; equality of all continuous-time sensor cylinders follows by analyticity."}


def rational_propagator(q, time, degree=12):
    """Normalized positive uniformization with rational total-variation tail."""
    n = len(q)
    rate = max(-q[i][i] for i in range(n))
    if not rate or not time:
        return identity(n), F(0)
    x = rate*time
    assert x < degree+2
    kernel = [[F(i==j)+q[i][j]/rate for j in range(n)] for i in range(n)]
    assert all(min(row) >= 0 and sum(row) == 1 for row in kernel)
    power = identity(n)
    polynomial = [[F(0)]*n for _ in range(n)]
    normalization = F(0)
    for k in range(degree+1):
        coefficient = x**k/factorial(k)
        normalization += coefficient
        polynomial = [[polynomial[i][j]+coefficient*power[i][j] for j in range(n)] for i in range(n)]
        power = matmul(power,kernel)
    remainder = x**(degree+1)/factorial(degree+1)/(1-x/F(degree+2))
    nominal = [[entry/normalization for entry in row] for row in polynomial]
    return nominal, remainder/(normalization+remainder)


def triple_probability(pi,d,p,q):
    return sum(rowmat(rowmat(rowmat(rowmat(rowmat(pi,d),p),d),q),d))


def subset_reversal_counterexample():
    q = [[F(x) for x in row] for row in [[-2,1,0,1],[1,-3,2,0],[0,1,-4,3],[4,0,1,-5]]]
    pi = [F(41,88),F(18,88),F(13,88),F(16,88)]
    sensor = [1,0,1,0]
    d = diagonal(sensor)
    check_generator(q,pi)
    qr = adjoint(q,pi)
    check_generator(qr,pi)
    mixed = jet(pi,d,q,1,2)-jet(pi,d,q,2,1)
    assert mixed == F(-23,22)
    for total in range(3):
        assert all(jet(pi,d,q,m,total-m) == jet(pi,d,q,total-m,m) for m in range(total+1))
    assert jet(pi,d,q,0,3) == jet(pi,d,q,3,0)
    singleton = exact_closure(q,pi,[1,0,0,0])
    complement = exact_closure(q,pi,[0,1,1,1])
    subset = exact_closure(q,pi,sensor)
    assert singleton["equivalent"] and complement["equivalent"] and not subset["equivalent"]
    t,s = F(1,100),F(1,50)
    pt,et = rational_propagator(q,t)
    ps,es = rational_propagator(q,s)
    gap = triple_probability(pi,d,pt,ps)-triple_probability(pi,d,ps,pt)
    radius = 2*(et+es)
    assert gap+radius < 0
    currents = [pi[i]*q[i][(i+1)%4]-pi[(i+1)%4]*q[(i+1)%4][i] for i in range(4)]
    assert currents == [F(23,88)]*4
    # Independent prior six-state example, not needed for the four-state proof.
    q6 = [[F(0)]*6 for _ in range(6)]
    for i in range(6):
        q6[i][i],q6[i][(i+1)%6],q6[i][(i-1)%6] = F(-4),F(3),F(1)
    d6 = diagonal([0,0,1,0,1,1])
    pi6 = [F(1,6)]*6
    old_mixed = jet(pi6,d6,q6,1,2)-jet(pi6,d6,q6,2,1)
    assert old_mixed == F(-13,3)
    return {"generator": [[str(x) for x in row] for row in q],
            "stationary_law":list(map(str,pi)),"binary_sensor":sensor,
            "stationary_adjoint":[[str(x) for x in row] for row in qr],
            "stationary_edge_currents":list(map(str,currents)),
            "mixed_derivative_difference":str(mixed),
            "leading_contrast":"H(t,s)-H(s,t)=-(23/44)*t*s*(s-t)+O((t+s)^4)",
            "singleton_closure":singleton,"singleton_complement_closure":complement,"two_state_subset_closure":subset,
            "fixed_gap_certificate":{"t":str(t),"s":str(s),"uniformization_degree":12,
                "contrast_lower":str(gap-radius),"contrast_upper":str(gap+radius),
                "contrast_display":float(gap),"error_radius":str(radius),"upper_bound_strictly_negative":True},
            "six_state_prior_example_mixed_derivative":str(old_mixed),
            "minimality_scope":"Four hidden states are minimal for a deterministic nontrivial binary partition with a stationary path arrow in a finite irreducible CTMC: at most three states leaves a singleton block."}


def discrimination_obstruction():
    p,q = F(1,3),F(2,3)
    errors = {}
    for n in [1,2,3,8,24]:
        risk = sum((F(comb(n,k),2)*min(p**k*(1-p)**(n-k),q**k*(1-q)**(n-k))
                    for k in range(n+1)),F(0))
        assert 0 < risk < F(1,2)
        errors[str(n)] = {"exact_equal_prior_error":str(risk),"display":float(risk)}
    assert errors["1"]["exact_equal_prior_error"] == "1/3"
    return {"one_record_probability_pair":[str(p),str(q)],"one_record_TV":"1/3",
            "finite_record_errors":errors,
            "all_finite_horizons_argument":"Every finite binary record has positive probability under both iid hypotheses, so their finite-record laws overlap and Bayes error is strictly positive.",
            "adaptive_stopping_scope":"A common almost-surely finite stopping rule still has the same support of terminating finite histories; perfect classification is impossible under these mutually positive kernels.",
            "infinite_record_distinction":"An infinite iid record can separate these fixed hypotheses by its limiting frequency; this does not supply finite-resource perfect discrimination."}


def fisher_bayes_mismatch():
    def a(theta):
        return F(1,2)+theta*(1-theta**2)/2
    def b(theta):
        return F(1,2)+theta/4
    for numerator in range(-100,101):
        theta = F(numerator,100)
        assert 0 <= a(theta) <= 1 and 0 <= b(theta) <= 1
    fisher_a = F(1,2)**2/F(1,4)
    fisher_b = F(1,4)**2/F(1,4)
    assert fisher_a == 1 and fisher_b == F(1,4)
    pairs = []
    for theta in [F(1,4),F(3,4),F(1)]:
        tv_a,tv_b = abs(a(theta)-a(-theta)),abs(b(theta)-b(-theta))
        pairs.append({"target_pair":[str(-theta),str(theta)],"TV_A":str(tv_a),"TV_B":str(tv_b),
                      "Bayes_risk_A":str((1-tv_a)/2),"Bayes_risk_B":str((1-tv_b)/2)})
    assert pairs[-1]["TV_A"] == "0" and pairs[-1]["Bayes_risk_B"] == "1/4"
    return {"parameter_domain":"[-1,1]","action_A_probability":"1/2+theta*(1-theta^2)/2",
            "action_B_probability":"1/2+theta/4","equal_declared_cost":1,
            "Fisher_at_zero_A":str(fisher_a),"Fisher_at_zero_B":str(fisher_b),
            "finite_pair_comparisons":pairs,
            "conclusion":"Local Fisher-information maximization chooses A near zero; for the target pair(-1,+1), A is exactly blind and B has one-record Bayes risk1/4. A Bellman recursion for Bayes loss does not thereby maximize Fisher information."}


def parameter_sign_is_not_current():
    models=[]
    for forward,backward in [(F(2),F(1)),(F(1),F(2))]:
        q=[[-forward,forward],[backward,-backward]]
        pi=[backward/(forward+backward),forward/(forward+backward)]
        check_generator(q,pi)
        current=pi[0]*q[0][1]-pi[1]*q[1][0]
        assert current == 0 and adjoint(q,pi) == q
        models.append({"rates":[str(forward),str(backward)],"pi":list(map(str,pi)),"stationary_current":str(current)})
    return {"models":models,
            "conclusion":"The two parameter settings have distinct stationary occupations and are statistically distinguishable, but each process is equilibrium and is its own stationary reverse. Recovering a parameter sign alone is not evidence of a stationary physical arrow."}


def representation_scaling():
    return [{"qubits":q,"Hilbert_dimension":2**q,"Hermitian_real_dimension":4**q,
             "dense_superoperator_entries":16**q,"dense_two_hypothesis_effect_dimension":2*4**q}
            for q in [5,10,20]]


def main():
    result={"status":"passed","evidence_kind":"Exact mathematical counterexamples and scoped implications; no empirical measurements",
            "subset_reversal":subset_reversal_counterexample(),
            "nonzero_not_perfect":discrimination_obstruction(),
            "Fisher_not_Bayes":fisher_bayes_mismatch(),
            "parameter_sign_not_current":parameter_sign_is_not_current(),
            "finite_dimension_not_compact_efficiency":representation_scaling(),
            "randomness":"none","dependencies":"Python standard library"}
    output=Path(__file__).resolve().parents[1]/"results/transfer_obstructions.json"
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":"passed","subset_mixed_derivative":result["subset_reversal"]["mixed_derivative_difference"],
                      "certified_finite_gap":result["subset_reversal"]["fixed_gap_certificate"]["contrast_display"],
                      "singleton_equivalent":result["subset_reversal"]["singleton_closure"]["equivalent"],
                      "arbitrary_subset_equivalent":result["subset_reversal"]["two_state_subset_closure"]["equivalent"],
                      "output":str(output)},indent=2))


if __name__=="__main__":
    main()
