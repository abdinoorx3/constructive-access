#!/usr/bin/env python3
"""Independent algebraic review of five application branches.

Reads declared inputs and saved outputs; never imports the producing modules.
Uses alternative calculations, exact arithmetic, and explicit policy replay.
All examples are synthetic. This is internal verification, not peer review.
"""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import combinations_with_replacement, product
from math import comb, ceil, exp, log
from pathlib import Path
import hashlib
import json
import sympy as S

ROOT = Path(__file__).resolve().parents[1]
NAMES = ('intervention_criterion', 'metabolic_flux', 'energy_identifiability',
         'quantum_scaling', 'nv_sensing')


def read(name):
    return json.loads((ROOT/'results'/f'{name}.json').read_text())


def exact(x):
    return F(x['exact'] if isinstance(x, dict) else x)


def dot(x, y):
    assert len(x) == len(y)
    return sum((a*b for a, b in zip(x, y)), F(0))


def fingerprints():
    data = read('intervention_criterion')
    certificates = []

    def check(matrix, target, errors, cert):
        matrix = [list(map(F, row)) for row in matrix]
        target, errors = list(map(F, target)), list(map(F, errors))
        w, h = map(lambda key: list(map(F, cert[key])), ('weights', 'dual_direction'))
        assert len(w) == len(matrix) and len(h) == len(target)
        assert [sum(w[i]*matrix[i][j] for i in range(len(matrix)))
                for j in range(len(target))] == target
        image = [dot(row, h) for row in matrix]
        assert all(abs(x) <= e for x, e in zip(image, errors))
        radius = sum(e*abs(x) for e, x in zip(errors, w))
        assert radius == dot(target, h) == F(cert['absolute_error'])
        # Construct a different positive least-favorable pair from the producer.
        center = [2*abs(x)+3 for x in h]
        left, right = [x-y for x, y in zip(center, h)], [x+y for x, y in zip(center, h)]
        assert min(left+right) > 0
        common = [dot(row, center) for row in matrix]
        assert all(abs(dot(row, left)-z) <= e and abs(dot(row, right)-z) <= e
                   for row, z, e in zip(matrix, common, errors))
        assert dot(target, right)-dot(target, left) == 2*radius
        certificates.append(str(radius))
        return radius

    for row in data['fingerprint_family']:
        r = F(row['selective_response'])
        for key, target, numerator in (('channel_1', (1,0), 2),
                                       ('channel_2', (0,1), 1+r),
                                       ('channel_difference', (1,-1), r+3)):
            cert = row[key]
            if r == 1:
                assert not cert['finite']
                h = [F(1), F(-1)]
                assert dot(target, h) != 0
                assert all(dot(list(map(F, line)), h) == 0 for line in row['fingerprint'])
            else:
                value = check(row['fingerprint'], target, [F(1,100)]*2, cert)
                assert value == numerator/(100*abs(r-1))
    check([[1,1],[F(1,2),1],[2,1]], [1,0], [F(1,100)]*3,
          data['redundant_intervention_optimum'])
    check([[1,1],[1,1]], [1,1], [F(1,100),F(1,50)],
          data['rank_deficient_but_target_identifiable'])
    check([[1,1],[F(1,2),1],[2,1]], [1,1], [0,F(1,100),F(1,100)],
          data['exact_observation_zero_error'])
    check([], [0,0], [], data['zero_target_without_observations'])
    check([[1,1],[F(1000001,1000000),1]], [1,0], [F(1,100)]*2,
          data['nearly_singular_full_rank'])
    return {'independent_exact_primal_dual_checks': len(certificates),
            'positive_least_favorable_pairs_constructed': len(certificates),
            'redundant_response_radius': '1/75', 'near_singular_radius': '20000',
            'scope': 'Full positive orthant, known fingerprint, full deterministic error box; complete-law fiber premises separately required.'}


def metabolic():
    data = read('metabolic_flux')
    intervals = [(F(399,100),F(401,100))]*2+[(F(249,100),F(251,100)),
                (F(349,100),F(351,100)),(F(49,100),F(51,100))]
    outputs = {key: [] for key in ('a','b','c','d','current','cycle_ratio')}
    entropy_values = []
    # Solve the four physical linear equations, rather than reusing inverse formulas.
    for k,l,kk,ll,q in product(*intervals):
        A = S.Matrix([[1,0,1,0],[0,1,0,1],[q,0,1,0],[0,q,0,1]])
        a,b,c,d = map(F, A.inv()*S.Matrix([k,l,kk,ll]))
        assert min(a,b,c,d) > 0
        piA, piB = l/(k+l), k/(k+l)
        current = piA*a-piB*b
        ratio = a*d/(b*c)
        for key, value in zip(outputs, (a,b,c,d,current,ratio)):
            outputs[key].append(value)
        with localcontext() as ctx:
            ctx.prec = 100
            entropy_values.append((Decimal(current.numerator)/Decimal(current.denominator))*
                (Decimal(ratio.numerator)/Decimal(ratio.denominator)).ln())
    expected = data['selective_inference']['calibrated_input_box']
    actual = {key: [str(min(values)),str(max(values))] for key,values in outputs.items()}
    assert actual == expected['sharp_intervals']
    # Symbolically check the coordinatewise degree condition underlying the
    # entire continuous-box result. Vertex samples alone would not prove it.
    k,l,kk,ll,q = symbols = S.symbols('k l kk ll q')
    a,b,c,d = (k-kk)/(1-q),(l-ll)/(1-q),(kk-q*k)/(1-q),(ll-q*l)/(1-q)
    exprs = [a,b,c,d,S.cancel((l*a-k*b)/(k+l)),S.cancel(a*d/(b*c))]
    degree_checks = 0
    for expr in exprs:
        num,den = S.fraction(S.cancel(expr))
        for symbol in symbols:
            assert S.degree(num,symbol) <= 1 and S.degree(den,symbol) <= 1
            degree_checks += 1
    with localcontext() as ctx:
        ctx.prec = 100
        dec = lambda v: Decimal(v.numerator)/Decimal(v.denominator)
        jlo,jhi = min(outputs['current']),max(outputs['current'])
        rlo,rhi = min(outputs['cycle_ratio']),max(outputs['cycle_ratio'])
        lower,upper = dec(jlo)*dec(rlo).ln(),dec(jhi)*dec(rhi).ln()
        boundlo,boundhi = map(F,expected['entropy_production']['outward_rational_interval'])
        assert dec(boundlo) < lower <= min(entropy_values)
        assert max(entropy_values) <= upper < dec(boundhi)
    recovered = data['selective_inference']['recovered_baseline']
    perturbed = data['selective_inference']['perturbed_model']
    assert F(recovered['channel1_current']) == 1
    assert F(perturbed['channel1_current']) == F(2,3)
    assert recovered['stationary'] != perturbed['stationary']
    for key, expected_current in (('equilibrium',0),('forward_cycle',1),('reverse_cycle',-1),
                                  ('same_affinity_alternative',F(7,8))):
        row = data['passive_path_equivalence'][key]
        a,b,c,d = map(F,row['rates'])
        assert a+c == b+d == 4
        assert (a-b)/2 == expected_current == F(row['channel1_current'])
    return {'vertices_independently_solved':32, 'symbolic_degree_checks':degree_checks,
            'sharp_intervals':actual, 'baseline_current':'1', 'perturbed_current':'2/3',
            'conservative_entropy_interval':list(map(str,(boundlo,boundhi))),
            'independent_100_digit_log_bracket':[str(lower),str(upper)],
            'scope':'Positive calibrated continuous input box; entropy requires channel thermodynamics; baseline and perturbed currents differ.'}


def hidden_energy():
    data = read('energy_identifiability')
    qs = [S.Matrix([[-1,1],[2,-2]]),S.Matrix([[-3,3],[4,-4]])]
    B = S.Matrix([[int(i//3==j) for j in range(2)] for i in range(6)])
    pi = S.Matrix([[S.Rational(2,3),S.Rational(1,3)]])
    alpha = S.Matrix([[S.Rational(2,9)]*3+[S.Rational(1,9)]*3])
    detectors = [S.diag(1,0),S.diag(0,1)]
    exact_words = 0
    for r in (0,1,3,9,99):
        fulls = []
        for q in qs:
            # Reconstruct every physical transition independently by state labels.
            G = S.zeros(6)
            for x,h in product(range(2),range(3)):
                i = 3*x+h
                G[i,3*(1-x)+h] = q[x,1-x]
                G[i,3*x+(h+1)%3] = 1+r
                G[i,3*x+(h-1)%3] = 1
                G[i,i] = -sum(G[i,j] for j in range(6))
            assert G*B == B*q
            for exponent in range(9):
                assert G**exponent*B == B*q**exponent
            fulls.append(G)
        assert alpha*fulls[0] == S.zeros(1,6)
        sigma = 0
        for i in range(6):
            for j in range(i+1,6):
                u,v = alpha[i]*fulls[0][i,j],alpha[j]*fulls[0][j,i]
                if u:
                    assert v
                    sigma += (u-v)*S.log(u/v)
        assert S.simplify(sigma-r*S.log(1+r)) == 0
        # Exponential random waiting time gives the exact resolvent transition.
        # Use it to check 340 complete finite instrument records for each r.
        small = [(S.eye(2)-q).inv()*d for q in qs for d in detectors]
        large = [(S.eye(6)-G).inv()*S.diag(*([int(y==x) for x in range(2) for _ in range(3)]))
                 for G in fulls for y in range(2)]
        for length in range(1,5):
            for word in product(range(4),repeat=length):
                v,w = pi,alpha
                for letter in word:
                    v,w = v*small[letter],w*large[letter]
                assert sum(v)==sum(w)
                exact_words += 1
    assert data['all_symbolic_checks_pass']
    return {'parameter_values_checked':[0,1,3,9,99],
            'exact_resolvent_records_checked':exact_words,
            'generator_power_intertwinings_checked':90,
            'stationary_entropy_rate':'r log(1+r)',
            'scope':'X-only access and controls; no calorimetry. The decoupled controlled dynamics and detector are declared assumptions.'}


def cs_power(c, s, m):
    """Multiple angle using a closed binomial expansion, not phase recurrence."""
    real = sum(((-1)**(j//2)*comb(m,j)*c**(m-j)*s**j for j in range(0,m+1,2)),F(0))
    imag = sum(((-1)**((j-1)//2)*comb(m,j)*c**(m-j)*s**j for j in range(1,m+1,2)),F(0))
    return real,imag


def quantum():
    data = read('quantum_scaling')
    a,b,lam = F(399,401),F(40,401),F(19,20)
    c,s = a*a-b*b,2*a*b
    assert c == F(data['model']['cos_theta']) and s == F(data['model']['sin_theta'])
    # Direct density matrices, separate from producer's Pauli transfer library.
    I = S.eye(2); X = S.Matrix([[0,1],[1,0]])
    U = a*I-S.I*b*X; R=(I-S.I*X)/S.sqrt(2)
    rho0 = S.diag(1,0)
    direct_probabilities = []
    rhoc,rhos = rho0,rho0
    for m in range(1,5):
        rhoc = S.simplify(lam*U*rhoc*U.H+(1-lam)*I/2)
        rhos = S.simplify(lam*(a*a*rhos+b*b*X*rhos*X)+(1-lam)*I/2)
        pc,ps = map(lambda rho:F(S.simplify((R*rho*R.H)[0,0])),(rhoc,rhos))
        cm,sm = cs_power(c,s,m)
        assert pc == (1-lam**m*sm)/2 and ps == F(1,2)
        direct_probabilities.append([str(pc),str(ps)])
    rows = []
    for row in data['depth_design']['depths']:
        m = row['depth']; cm,sm = cs_power(c,s,m)
        gap = lam**m*abs(sm)/2
        residual = F(1,1000)+m*F(1,10000)
        robust = gap-2*residual
        assert gap == F(row['nominal_tv']) and robust == F(row['robust_gap'])
        count = None if robust <= 0 else ceil(F(5)/(robust*robust))
        assert count == row['sufficient_records_each_error_lt_0_1']
        if count is not None:
            assert exp(-float(count*robust*robust/2)) < .1
            rows.append((m*count,m,count))
    best = min(rows)
    assert best == (240,4,60)
    assert rows[0][0] == 590
    # Independently check Pinsker constants using high precision KL values.
    lower_bounds=[]
    with localcontext() as ctx:
        ctx.prec=100
        for row in data['tiny_signal_lower_bounds']:
            epsilon=F(row['epsilon']); e=Decimal(epsilon.numerator)/Decimal(epsilon.denominator)
            kl=2*e*((1+2*e)/(1-2*e)).ln()
            assert kl <= 8*e*e/(1-2*e) <= 16*e*e
            count=ceil(F(4,5)**2/(8*epsilon**2))
            assert count == row['necessary_calls_pinsker_bound']
            lower_bounds.append(count)
    # Exact binomial overlap is a separate finite-horizon error computation.
    for row in data['tiny_signal_exact_errors']:
        n=row['records']; p=F(9,16)
        overlap=sum((comb(n,k)*min(p**k*(1-p)**(n-k),(1-p)**k*p**(n-k))
                     for k in range(n+1)),F(0))/2
        assert overlap == F(row['exact_bayes_error'])
    g=lam*s/2-2*(F(1,1000)+F(1,10000))
    for row in data['promised_local_dictionary']['scaling']:
        B=row['blocks']; M=row['records_per_block_sufficient']
        assert M*B == row['total_unknown_channel_calls']
        assert log(2*B)-float(M*g*g/2) < log(.05)
    return {'direct_density_matrix_depths':4,'independent_depth_menu_checks':80,
            'best_menu_calls':best[0],'best_menu_depth':best[1],'best_menu_records':best[2],
            'depth_one_calls':590,'replacer_necessary_call_bounds':lower_bounds,
            'four_exact_binomial_risks_checked':True,
            'scope':'Specific channels and known calibrated control; finite-menu sufficient bound, not global optimality or universal tomography.'}


def nv():
    data=read('nv_sensing')
    hypotheses=[(row['sign'],exact(row['fixed_bias'])) for row in data['hypotheses']]
    probs,costs={},{}
    for row in data['actions']:
        name,m=row['name'],row['duration']; cm,sm=cs_power(F(4,5),F(3,5),m)
        orientation=-1 if name.startswith('-') else 1
        quadrature='X' if 'X' in name else 'Y'
        p=[F(1,2)+bias+F(4,5)**(m+1)*orientation*(cm if quadrature=='X' else sign*sm)/2
           for sign,bias in hypotheses]
        assert p == list(map(exact,row['probability_by_hypothesis']))
        probs[name]=p; costs[name]=m+2
        if quadrature=='X': assert p[:2]==p[2:]
    def leafrisk(likelihoods):
        return min(sum(p for p,(s,b) in zip(likelihoods,hypotheses) if s<0),
                   sum(p for p,(s,b) in zip(likelihoods,hypotheses) if s>0))/4
    def replay(node,path=(),spent=0):
        if node.get('stop'):
            likes=[F(1)]*4
            for action,outcome in path:
                likes=[x*(p if outcome else 1-p) for x,p in zip(likes,probs[action])]
            declared=node['declare_sign']
            error=sum(p for p,(s,b) in zip(likes,hypotheses) if s!=declared)/4
            assert error==leafrisk(likes)
            return error,sum(likes)*spent/4,spent,1,sum(likes)/4
        action=node['action']; assert node['cost']==costs[action]
        parts=[replay(node['branches'][str(y)],path+((action,y),),spent+costs[action]) for y in (0,1)]
        return (sum(t[0] for t in parts),sum(t[1] for t in parts),max(t[2] for t in parts),
                sum(t[3] for t in parts),sum(t[4] for t in parts))
    policies=[]
    for budget,row in [(12,data['optimal_adaptive_bayes']),
                       (15,data['larger_budget_extension']['adaptive'])]:
        risk,expected,maximum,leaves,mass=replay(row['policy'])
        assert mass==1 and risk==exact(row['risk']) and expected==exact(row['expected_cost'])
        assert maximum==row['maximum_cost']<=budget and leaves==row['leaf_count']
        policies.append({'budget':budget,'risk':str(risk),'expected_cost':str(expected),
                         'max_cost':maximum,'leaves':leaves})
    # Strong fixed-plan baseline via all multisets, then grouped binomial counts
    # for repeated actions. This differs from producer's ordered bit strings.
    names=tuple(probs)
    def fixedrisk(plan):
        counts={a:plan.count(a) for a in set(plan)}
        risk=F(0)
        for numbers in product(*(range(n+1) for n in counts.values())):
            likes=[F(1)]*4
            for (action,n),ones in zip(counts.items(),numbers):
                likes=[x*comb(n,ones)*p**ones*(1-p)**(n-ones) for x,p in zip(likes,probs[action])]
            risk+=leafrisk(likes)
        return risk
    baselines=[]
    for budget,key in [(12,data['optimal_nonadaptive']),
                       (15,data['larger_budget_extension']['best_nonadaptive'])]:
        best=F(1,2); examined=0
        for n in range(budget//3+1):
            for plan in combinations_with_replacement(names,n):
                if sum(costs[a] for a in plan)<=budget:
                    best=min(best,fixedrisk(plan)); examined+=1
        assert best==exact(key['risk']) and examined==key['all_multisets_checked']
        baselines.append({'budget':budget,'all_multisets':examined,'risk':str(best)})
    assert F(policies[0]['risk']) == F(baselines[0]['risk'])
    assert F(baselines[1]['risk'])-F(policies[1]['risk']) == F(6,3125)
    # Full deterministic depth-two tree enumeration at budget six. Terminal
    # decisions are optimized directly from joint path probabilities.
    best=F(1,2); count=1
    for a in names:
        if costs[a]>6: continue
        choices=[None]+[b for b in names if costs[b]<=6-costs[a]]
        for left,right in product(choices,repeat=2):
            risk=F(0)
            for outcome,b in enumerate((left,right)):
                if b is None:
                    risk+=leafrisk([p if outcome else 1-p for p in probs[a]])
                else:
                    for z in (0,1):
                        risk+=leafrisk([(pa if outcome else 1-pa)*(pb if z else 1-pb)
                                        for pa,pb in zip(probs[a],probs[b])])
            best=min(best,risk);count+=1
    assert str(best)==data['exhaustive_policy_check']['exact_risk']
    assert count==data['exhaustive_policy_check']['all_deterministic_trees']
    # Fixed nuisance survives multiple shots; it is not re-mixed independently.
    pp=probs['Y1'][2:]
    assert sum(p*p for p in pp)/2-(sum(pp)/2)**2 == F(1,400)
    assert fixedrisk(tuple(data['local_fisher_greedy']['plan']))==F(1,2)
    assert F(1,2)*F(99,100)**161 <= F(1,10) < F(1,2)*F(99,100)**160
    return {'independent_action_probabilities':16,'policy_replays':policies,
            'exhaustive_fixed_baselines':baselines,
            'budget_six_all_trees':count,'budget_six_optimum':str(best),
            'budget15_feedback_absolute_risk_gain':'6/3125',
            'fisher_greedy_sign_risk':'1/2','fixed_nuisance_redraw_error':'1/400',
            'scope':'Finite menu, four fixed hypotheses, timing budget; exact policy replay does not independently establish full-budget Bellman optimality beyond the reviewed induction proof.'}


def hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for name in NAMES for folder,suffix in [('code','py'),('results','json')]
            for p in [ROOT/folder/f'{name}.{suffix}']}


def main():
    before=hashes()
    result={'status':'PASS','internal_independent_review':True,'empirical_data':False,
            'fingerprints':fingerprints(),'metabolic':metabolic(),'hidden_energy':hidden_energy(),
            'quantum':quantum(),'nv':nv()}
    assert before==hashes(), 'Reviewed module changed during audit; rerun after freeze.'
    result['reviewed_sha256']=before
    result['method']='No imports from the five producing modules; exact witnesses, alternate algebra, direct density matrices, and complete policy replay.'
    (ROOT/'results'/'cross_domain_review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','minimax_certificates':result['fingerprints']['independent_exact_primal_dual_checks'],
                      'metabolic_vertices':32,'energy_records':result['hidden_energy']['exact_resolvent_records_checked'],
                      'quantum_depths':80,'nv_feedback_gain':result['nv']['budget15_feedback_absolute_risk_gain']}))


if __name__=='__main__':
    main()
