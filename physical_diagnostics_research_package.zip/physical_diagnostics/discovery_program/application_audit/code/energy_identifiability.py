#!/usr/bin/env python3
"""Exact access-equivalent CTMCs with different hidden dissipation.

Abdinoor / 2D Labs / 12 October 2026.
Run from any directory; results go to ../results/energy_identifiability.json.
Symbolic identities prove the finite model claim. Floating-point matrix
exponentials are additional consistency checks, not its proof.
"""
from __future__ import annotations

import json
from pathlib import Path
import platform

import numpy as np
import scipy
from scipy.linalg import expm
import sympy as sp


def hidden_generator(r):
    result = sp.zeros(3)
    for i in range(3):
        result[i, (i + 1) % 3] = 1 + r
        result[i, (i - 1) % 3] = 1
        result[i, i] = -(2 + r)
    return result


def entropy_production(generator, stationary):
    """Dimensionless stationary rate, with all states even under reversal."""
    terms = []
    for i in range(generator.rows):
        for j in range(i + 1, generator.rows):
            forward = sp.simplify(stationary[i] * generator[i, j])
            reverse = sp.simplify(stationary[j] * generator[j, i])
            if forward == 0 and reverse == 0:
                continue
            assert forward != 0 and reverse != 0
            terms.append((forward - reverse) * sp.log(forward / reverse))
    return sp.simplify(sum(terms))


def main():
    r = sp.Symbol("r", nonnegative=True)
    q0 = sp.Matrix([[-1, 1], [2, -2]])
    q1 = sp.Matrix([[-3, 3], [4, -4]])
    controls = [q0, q1]
    rho = hidden_generator(r)
    pi = sp.Matrix([[sp.Rational(2, 3), sp.Rational(1, 3)]])
    nu = sp.ones(1, 3) / 3
    full_pi = sp.kronecker_product(pi, nu)
    aggregation = sp.kronecker_product(sp.eye(2), sp.ones(3, 1))
    detectors = [sp.diag(1, 0), sp.diag(0, 1)]
    full_controls = [
        sp.kronecker_product(q, sp.eye(3))
        + sp.kronecker_product(sp.eye(2), rho)
        for q in controls
    ]
    checks = {}
    checks["hidden_generator_row_sums_zero"] = rho * sp.ones(3, 1) == sp.zeros(3, 1)
    checks["hidden_stationary_law_independent_of_r"] = nu * rho == sp.zeros(1, 3)
    checks["visible_stationary_law"] = pi * q0 == sp.zeros(1, 2)
    checks["full_stationary_law_independent_of_r"] = full_pi * full_controls[0] == sp.zeros(1, 6)
    checks["initial_law_aggregates"] = full_pi * aggregation == pi
    for a, (q, generator) in enumerate(zip(controls, full_controls)):
        checks[f"generator_intertwining_control_{a}"] = generator * aggregation == aggregation * q
    for y, detector in enumerate(detectors):
        full_detector = sp.kronecker_product(detector, sp.eye(3))
        checks[f"detector_intertwining_outcome_{y}"] = full_detector * aggregation == aggregation * detector
    # A visible reset is an additional allowed intervention; it also cannot
    # disclose r.  The same identity holds for arbitrary visible instruments.
    reset = sp.Matrix([[1, 0], [1, 0]])
    checks["reset_intertwining"] = sp.kronecker_product(reset, sp.eye(3)) * aggregation == aggregation * reset
    hidden_sigma = entropy_production(rho, nu)
    full_sigma = entropy_production(full_controls[0], full_pi)
    checks["hidden_entropy_formula"] = sp.simplify(hidden_sigma - r * sp.log(1 + r)) == 0
    checks["full_entropy_equals_hidden_entropy"] = sp.simplify(full_sigma - hidden_sigma) == 0
    checks["visible_entropy_production_zero"] = entropy_production(q0, pi) == 0
    # The controls do not commute: access equivalence is not due to using
    # only a single time-homogeneous setting.
    checks["visible_controls_noncommuting"] = q0 * q1 != q1 * q0
    assert all(checks.values()), checks

    schedules = [
        [(0, 0.2, 0), (1, 0.4, 1), (0, 0.3, 1)],
        [(1, 0.4, 1), (0, 0.1, 0), (1, 0.7, 1), (0, 0.2, 0)],
        [(0, 0.6, 1), (1, 0.2, 1)],
    ]
    numerical_checks = []
    parameter_values = [0, 1, 3, 9, 99]
    for schedule in schedules:
        visible_row = np.array(pi, dtype=float)
        for action, duration, outcome in schedule:
            visible_row = visible_row @ expm(np.array(controls[action], dtype=float) * duration)
            visible_row = visible_row @ np.array(detectors[outcome], dtype=float)
        probability = float(visible_row.sum())
        errors = []
        for value in parameter_values:
            full_row = np.array(full_pi, dtype=float)
            for action, duration, outcome in schedule:
                gen = np.array(full_controls[action].subs(r, value), dtype=float)
                det = np.array(sp.kronecker_product(detectors[outcome], sp.eye(3)), dtype=float)
                full_row = full_row @ expm(gen * duration) @ det
            errors.append(abs(float(full_row.sum()) - probability))
        assert max(errors) < 1e-12
        numerical_checks.append({"schedule_action_duration_outcome": schedule,
                                 "visible_probability": probability,
                                 "maximum_full_vs_visible_absolute_error": max(errors)})

    rows = [{"r": value,
             "full_stationary_probabilities_exact": [str(x) for x in full_pi],
             "accessible_stationary_probabilities_exact": [str(x) for x in pi],
             "dimensionless_entropy_rate_exact": str(full_sigma.subs(r, value)),
             "dimensionless_entropy_rate_numeric": float(full_sigma.subs(r, value)),
             "stationary_accessible_path_reversal_relative_entropy_rate": 0}
            for value in parameter_values]
    report = {
        "title": "Identical physical access, different hidden energy dissipation",
        "authors": "Abdinoor / 2D Labs",
        "date": "2026-10-12",
        "evidence_type": "exact finite stochastic-model counterexample; no physical experiment",
        "conventions": {
            "generator": "row generator; states ordered (visible X, hidden H)",
            "time": "baseline jump rate kappa=1 per model time unit",
            "parameter": "dimensionless r>=0; hidden clockwise rate kappa*(1+r), reverse kappa",
            "physical_interpretation": "If an isothermal, channel-resolved local-detailed-balance realization is supplied, hidden dissipated power = k_B*T*kappa*r*log(1+r).",
            "excluded_access": "No hidden-state measurement, calorimetry, reservoir/fuel sensor, or coupling of controls/sensors to H."
        },
        "matrices_exact": {"Q0": str(q0), "Q1": str(q1), "R_r": str(rho),
                           "aggregation_B": str(aggregation),
                           "G_r_a": "Q_a tensor I_3 + I_2 tensor R_r"},
        "symbolic_checks": checks,
        "all_symbolic_checks_pass": all(checks.values()),
        "proof_certificate": {
            "identities": "G_r^a B=B Q_a; (D_y tensor I) B=B D_y; alpha B=pi; (K tensor I) B=B K.",
            "semigroups": "Power series gives exp(t G_r^a) B=B exp(t Q_a) for every t>=0.",
            "records": "Multiply these identities along each action/outcome record. Every finite record probability is independent of r. Common causal randomized policies attach the same conditional action factors, so retain equivalence.",
            "dissipation": "Each hidden clockwise edge has stationary current r/3 and affinity log(1+r); three edges give r log(1+r). Independent visible stationary chain contributes zero.",
            "unboundedness": "For r>=1, r log(1+r)>=r log(2); without a specified upper rate/fuel bound the possible dissipation has no finite upper bound.",
            "occupancies": "Even the full stationary six-state occupancy vector is identical for all r."
        },
        "parameter_examples": rows,
        "numerical_record_checks": numerical_checks,
        "numerical_tolerance": 1e-12,
        "scope": "This disproves universal total-energy inference from restricted access. It does not preclude target-specific current inference within a calibrated model, or power estimation from added meters and validated thermodynamics.",
        "versions": {"python": platform.python_version(), "sympy": sp.__version__,
                     "numpy": np.__version__, "scipy": scipy.__version__},
        "randomness": "none"
    }
    output = Path(__file__).resolve().parents[1] / "results" / "energy_identifiability.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"all_symbolic_checks_pass": all(checks.values()),
                      "symbolic_checks": len(checks),
                      "record_checks": len(numerical_checks),
                      "maximum_numeric_error": max(x["maximum_full_vs_visible_absolute_error"] for x in numerical_checks),
                      "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
