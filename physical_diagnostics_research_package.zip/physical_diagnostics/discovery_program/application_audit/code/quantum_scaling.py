#!/usr/bin/env python3
"""Exact targeted quantum-noise diagnosis and scaling counterexamples.

Synthetic calibrated channels, no hardware data. Earlier releases are imported
read-only for witness checking; all channels below are independently derived.
"""
from datetime import datetime, timezone
from fractions import Fraction as F
from math import ceil, comb
from pathlib import Path
import hashlib
import json
import platform
import sys

import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
PRIOR = ROOT.parent/"access_theory"/"code"
sys.path.insert(0, str(PRIOR))
from accesskit import LinearRepresentation, compare_linear_representations, verify_access_result

I = sp.eye(2)
X = sp.Matrix([[0, 1], [1, 0]])
Y = sp.Matrix([[0, -sp.I], [sp.I, 0]])
Z = sp.diag(1, -1)
PAULIS = [I, X, Y, Z]
RHO = (I+Z)/2


def transfer(kraus):
    assert sp.simplify(sum((k.H*k for k in kraus), sp.zeros(2))-I) == sp.zeros(2)
    out = sp.Matrix([[sp.simplify(sp.trace(outp*sum((k*inp*k.H for k in kraus), sp.zeros(2)))/2)
                      for outp in PAULIS] for inp in PAULIS])
    assert all(x.is_Rational for x in out)
    return out


def parameters(t):
    a, b = (1-t*t)/(1+t*t), 2*t/(1+t*t)
    assert a*a+b*b == 1
    c, s = a*a-b*b, 2*a*b
    assert c*c+s*s == 1
    return a, b, c, s


def channels(t, visibility):
    a, b, c, s = parameters(t)
    u = a*I-sp.I*b*X
    dep = [sp.sqrt((1+3*visibility)/4)*I]+[sp.sqrt((1-visibility)/4)*p for p in [X, Y, Z]]
    coherent = transfer([d*u for d in dep])
    stochastic = transfer([d*k for d in dep for k in [a*I, b*X]])
    expected_c = sp.diag(1, visibility, visibility*c, visibility*c)
    expected_c[2, 3], expected_c[3, 2] = visibility*s, -visibility*s
    expected_s = sp.diag(1, visibility, visibility*c, visibility*c)
    assert coherent == expected_c and stochastic == expected_s
    return coherent, stochastic


def library(matrix):
    rotate = transfer([(I-sp.I*X)/sp.sqrt(2)])
    p0, p1 = (I+Z)/2, (I-Z)/2
    # Outcome maps are CP but individually trace-nonincreasing.
    read = {}
    for name, p in [("0", p0), ("1", p1)]:
        read[("read_z", name)] = sp.Matrix([[sp.simplify(sp.trace(q*p*r*p)/2)
                                             for q in PAULIS] for r in PAULIS])
    read[("rotate_x", ".")] = rotate
    read[("evolve", ".")] = matrix
    return LinearRepresentation([1, 0, 0, 1], read, [1, 0, 0, 0])


def run():
    t, visibility = F(1, 20), F(19, 20)
    a, b, c, s = parameters(t)
    coherent, stochastic = channels(t, visibility)
    reps = [library(coherent), library(stochastic)]
    witness = compare_linear_representations(*reps)
    assert not witness.equivalent and verify_access_result(*reps, witness)
    word_z1 = (("evolve", "."), ("read_z", "0"))
    word_y1 = (("evolve", "."), ("rotate_x", "."), ("read_z", "0"))
    word_z2 = (("evolve", "."), ("evolve", "."), ("read_z", "0"))
    z1 = [r.word_probability(word_z1) for r in reps]
    y1 = [r.word_probability(word_y1) for r in reps]
    z2 = [r.word_probability(word_z2) for r in reps]
    assert z1[0] == z1[1] == (1+visibility*c)/2
    assert y1 == [(1-visibility*s)/2, F(1, 2)]
    assert abs(z2[0]-z2[1]) == visibility**2*s*s/2
    rb_parameter = visibility*(1+2*c)/3
    average_fidelity = (1+rb_parameter)/2
    assert average_fidelity == F((3+sp.trace(coherent[1:4, 1:4]))/6)
    assert average_fidelity == F((3+sp.trace(stochastic[1:4, 1:4]))/6)
    unitarity_c = F(sp.trace(coherent[1:4, 1:4].T*coherent[1:4, 1:4])/3)
    unitarity_s = F(sp.trace(stochastic[1:4, 1:4].T*stochastic[1:4, 1:4])/3)
    assert unitarity_c == visibility**2 > unitarity_s == visibility**2*(1+2*c*c)/3

    # Negative control: only Z measurements and evolution followed by mandatory
    # unread Z dephasing. No coherent preparation/rotation is available.
    dz = sp.diag(1, 0, 0, 1)
    blind = []
    for rep, matrix in zip(reps, [coherent, stochastic]):
        kernels = {k: v for k, v in rep.kernels.items() if k[0] == "read_z"}
        kernels[("evolve_dephased", ".")] = matrix*dz
        blind.append(LinearRepresentation([1, 0, 0, 1], kernels, [1, 0, 0, 0]))
    obstruction = compare_linear_representations(*blind)
    assert obstruction.equivalent and verify_access_result(*blind, obstruction)

    # Exact sequence-depth scan. The comparison uses unknown-channel calls,
    # separately recording preparations/known rotations/readouts per record.
    cm, sm = F(1), F(0)
    depths = []
    base_tv, per_call_tv = F(1, 1000), F(1, 10000)
    # e^(5/2)>10 via a positive finite Taylor lower sum, hence M>=5/g^2
    # makes exp(-M*g^2/2)<0.1 for each hypothesis under the robust midpoint.
    assert sum((F(5, 2)**k/sp.factorial(k) for k in range(5)), F(0)) > 10
    for m in range(1, 81):
        cm, sm = cm*c-sm*s, sm*c+cm*s
        gap = visibility**m*abs(sm)/2
        error = base_tv+m*per_call_tv
        robust_gap = gap-2*error
        records = None if robust_gap <= 0 else ceil(5/(robust_gap*robust_gap))
        depths.append({"depth": m, "cos_mtheta": str(cm), "sin_mtheta": str(sm),
            "coherent_p0_after_known_rotation": str((1-visibility**m*sm)/2),
            "stochastic_p0_after_known_rotation": "1/2", "nominal_tv": str(gap),
            "per_hypothesis_record_tv_bound": str(error), "robust_gap": str(robust_gap),
            "sufficient_records_each_error_lt_0_1": records,
            "unknown_channel_calls": None if records is None else records*m,
            "preparations_known_rotations_readouts_each": records})
        if m <= 4:
            actual = [F((r.initial*mat**m*r.kernels[("rotate_x", ".")]*r.kernels[("read_z", "0")]*r.terminal)[0])
                      for r, mat in zip(reps, [coherent, stochastic])]
            assert actual == [(1-visibility**m*sm)/2, F(1, 2)]
    best_gap = max(depths, key=lambda row: F(row["nominal_tv"]))
    feasible = [row for row in depths if row["unknown_channel_calls"] is not None]
    best_calls = min(feasible, key=lambda row: (row["unknown_channel_calls"], row["depth"]))
    assert best_calls["unknown_channel_calls"] < depths[0]["unknown_channel_calls"]
    assert any(row["robust_gap"].startswith("-") for row in depths)

    # Independent tiny-signal lower bound, even for arbitrary adaptive processing
    # of outputs of replacer channels with commuting qubit states.
    target_error = F(1, 10)
    tiny_signals = []
    for denominator in [8, 32, 128, 1024]:
        epsilon = F(1, denominator)
        bound = (1-2*target_error)**2/(8*epsilon*epsilon)
        tiny_signals.append({"epsilon": str(epsilon), "single_record_tv": str(2*epsilon),
                            "necessary_calls_pinsker_bound": ceil(bound),
                            "paired_dimension": 8, "general_witness_length_bound": 7,
                            "explicit_nonzero_protocol_length": 2})

    def binomial_error(p, n):
        return sum((comb(n, k)*min(p**k*(1-p)**(n-k), (1-p)**k*p**(n-k))
                    for k in range(n+1)), F(0))/2
    finite_counts = [{"records": n, "epsilon": "1/16", "exact_bayes_error": str(binomial_error(F(9, 16), n))}
                     for n in [1, 10, 100, 500]]
    assert F(finite_counts[0]["exact_bayes_error"]) > F(finite_counts[-1]["exact_bayes_error"])

    # Fixed, local three-channel dictionary: +rotation, twirl, -rotation.
    # One phase-sensitive setting has three separated means. Uniform calibrated
    # residual bounds reduce the nearest-nominal-mean separation to g.
    gap = visibility*s/2
    residual = base_tv+per_call_tv
    g = gap-2*residual
    family_alpha = F(1, 20)
    local_scaling = []
    for blocks in [1, 10, 100, 1000]:
        ratio = 2*blocks/family_alpha
        log_upper = 0
        while 2**log_upper < ratio:
            log_upper += 1
        # ln(ratio)<=ceil(log2(ratio)); union error <=2B exp(-M*g²/2).
        count_per_block = ceil(2*log_upper/(g*g))
        local_scaling.append({"blocks": blocks, "records_per_block_sufficient": count_per_block,
                              "total_unknown_channel_calls": blocks*count_per_block,
                              "total_readouts": blocks*count_per_block,
                              "family_error_upper": str(family_alpha)})
    old_files = [ROOT.parent/"manuscript"/"quantum_access.tex",
                 PRIOR/"quantum_instruments.py", PRIOR/"accesskit.py"]
    output = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(),
        "sympy": sp.__version__, "status": "all exact checks passed",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "prior_read_only_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in old_files},
        "model": {"t": str(t), "a": str(a), "b": str(b), "cos_theta": str(c), "sin_theta": str(s),
                  "depolarizing_visibility_per_call": str(visibility),
                  "kraus_completeness_checked": True, "physical_data": False},
        "same_fidelity_different_coherence": {
            "average_fidelity_both": str(average_fidelity), "ideal_gate_independent_RB_decay_parameter_both": str(rb_parameter),
            "unitarity_coherent_with_depolarization": str(unitarity_c),
            "unitarity_stochastic_with_depolarization": str(unitarity_s),
            "one_evolve_z_probabilities": list(map(str, z1)),
            "one_evolve_phase_sensitive_probabilities": list(map(str, y1)),
            "two_evolve_z_probabilities": list(map(str, z2)),
            "note": "Equality of a fitted first-moment RB parameter is not equality of every retained randomized-sequence record."},
        "finite_witness": witness.to_dict(False), "dephased_negative_control": obstruction.to_dict(False),
        "depth_design": {"menu_depths": [1, 80], "records_independent": True,
                         "calibration_base_tv_each_hypothesis": str(base_tv),
                         "calibration_half_diamond_error_per_call": str(per_call_tv),
                         "maximum_nominal_gap_depth": best_gap["depth"],
                         "minimum_certified_unknown_calls_depth": best_calls["depth"],
                         "depth_one_unknown_calls": depths[0]["unknown_channel_calls"],
                         "best_unknown_calls": best_calls["unknown_channel_calls"],
                         "best_records": best_calls["sufficient_records_each_error_lt_0_1"],
                         "scope": "Best of stated finite menu under one sufficient bound; not optimal statistical design or measured energy.",
                         "depths": depths},
        "tiny_signal_lower_bounds": tiny_signals, "tiny_signal_exact_errors": finite_counts,
        "unrestricted_dimension_scaling": [{"qubits": n, "hilbert_dimension": 2**n,
              "paired_real_dimension": 2*4**n, "finite_word_bound": 2*4**n-1,
              "interior_CPTP_real_parameters": 16**n-4**n} for n in [1, 2, 5, 10, 20]],
        "promised_local_dictionary": {"labels": ["positive coherent rotation", "stochastic Pauli twirl", "negative coherent rotation"],
             "nominal_probabilities": list(map(str, [(1-visibility*s)/2, F(1, 2), (1+visibility*s)/2])),
             "minimum_nominal_separation": str(gap), "robust_margin_twice": str(g),
             "conditions": ["Known independent local channel model and independently characterized access",
                            "No unmodeled cross-talk, memory or spectator-dependent effects",
                            "Independent prepared records within each block; calibration bounds valid",
                            "Every block belongs to the stated three-channel dictionary"],
             "scaling": local_scaling},
        "claims_excluded": ["Fault-tolerance overhead solved", "Constant-cost unrestricted characterization",
                            "Randomized benchmarking senses only stochastic errors", "Empirical validation",
                            "The original boundary-driven XX result diagnoses coherent gate noise"]}
    path = ROOT/"results"/"quantum_scaling.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps({"status": "PASS", "best_depth": best_calls["depth"],
                      "unknown_calls_depth_one": depths[0]["unknown_channel_calls"],
                      "best_unknown_calls": best_calls["unknown_channel_calls"], "output": str(path)}))


if __name__ == "__main__":
    run()
