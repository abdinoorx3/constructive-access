#!/usr/bin/env python3
"""Plot separately scoped, reproducible application calculations."""
from fractions import Fraction as F
import hashlib
import json
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR", "/tmp/physical-diagnostics-matplotlib")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/physical-diagnostics-fontcache")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    names = ["intervention_criterion", "quantum_scaling", "nv_sensing", "energy_identifiability"]
    data = {n:json.loads((ROOT/"results"/(n+".json")).read_text()) for n in names}
    plt.rcParams.update({"font.size":9, "axes.spines.top":False,
                         "axes.spines.right":False, "pdf.fonttype":42})
    fig, axes = plt.subplots(2,2,figsize=(9.0,6.5),layout="constrained")
    blue, orange, grey = "#28618b", "#b8662e", "#555e68"
    ax=axes[0,0]
    rows = [r for r in data[names[0]]["fingerprint_family"]
            if F(r["selective_response"]) in (F(1,2),F(9,10),F(99,100),F(999,1000))]
    x=[float(abs(1-F(r["selective_response"]))) for r in rows]
    y=[float(F(r["channel_1"]["absolute_error"])) for r in rows]
    assert y == [0.04,0.2,2.0,20.0]
    ax.loglog(x,y,"o-",color=blue)
    ax.set(xlabel="Intervention separation |1 − r|",
           ylabel="Optimal worst-case rate error",
           title="A  Reaction selectivity and precision")
    ax.text(.04,.07,"Rate-error allowance ε = 0.01\nFull positive parameter class",
            transform=ax.transAxes,fontsize=8)
    ax.grid(alpha=.17,which="both")

    ax=axes[0,1]
    q=data[names[1]]["depth_design"]
    depths=[d for d in q["depths"] if d["depth"]<=12]
    valid=[d for d in depths if d["unknown_channel_calls"] is not None]
    ax.plot([d["depth"] for d in valid],[d["unknown_channel_calls"] for d in valid],
            "o-",color=blue,markersize=4)
    best=next(d for d in valid if d["depth"]==4)
    assert best["unknown_channel_calls"]==240
    ax.scatter([4],[240],s=65,color=orange,zorder=4)
    ax.annotate("240 calls at depth 4",xy=(4,240),xytext=(5,440),
                arrowprops={"arrowstyle":"-","color":grey},fontsize=8)
    ax.set(xlabel="Unknown-channel calls per record",
           ylabel="Sufficient total unknown-channel calls",
           title="B  Calibrated quantum diagnosis",xticks=[1,4,7,10,12])
    ax.text(.04,.92,"Displayed subset of tested depths 1–80",
            transform=ax.transAxes,fontsize=8)
    ax.grid(alpha=.17)

    ax=axes[1,0]
    n=data[names[2]]
    fixed=[n["optimal_nonadaptive"]["risk"]["float"],
           n["larger_budget_extension"]["best_nonadaptive"]["risk"]["float"]]
    adaptive=[n["optimal_adaptive_bayes"]["risk"]["float"],
              n["larger_budget_extension"]["adaptive"]["risk"]["float"]]
    assert F(n["larger_budget_extension"]["absolute_improvement"]["exact"])==F(6,3125)
    ax.plot([12,15],fixed,"s--",color=grey,label="Best nonadaptive")
    ax.plot([12,15],adaptive,"o-",color=blue,label="Adaptive")
    ax.set(xlabel="Maximum time budget (ticks)",ylabel="Exact sign Bayes risk",
           title="C  Finite-menu Ramsey sensing",xticks=[12,15],
           ylim=(.1568,.161))
    ax.text(.06,.13,"Absolute gain at 15 ticks: 0.00192\nFour fixed hypotheses; hypothetical channels",
            transform=ax.transAxes,fontsize=8)
    ax.legend(frameon=False,loc="upper right",fontsize=8)
    ax.grid(alpha=.17)

    ax=axes[1,1]
    examples=[e for e in data[names[3]]["parameter_examples"] if e["r"]<=9]
    ax.plot([e["r"] for e in examples],
            [e["dimensionless_entropy_rate_numeric"] for e in examples],
            "o-",color=orange)
    ax.set(xlabel="Unobserved cycle parameter r",
           ylabel="Hidden entropy rate / (kB per model time)",
           title="D  Energy-account obstruction",xticks=[0,1,3,9])
    ax.text(.06,.82,"Complete accessible record law\nis identical at every point",
            transform=ax.transAxes,fontsize=8)
    ax.grid(alpha=.17)
    fig.suptitle("Different targets require different access and resource models",
                 fontsize=12,fontweight="semibold")
    paths=[ROOT/"manuscript/application_results.pdf",ROOT/"manuscript/application_results.png"]
    fig.savefig(paths[0],bbox_inches="tight")
    fig.savefig(paths[1],dpi=220,bbox_inches="tight")
    plt.close(fig)
    report={"status":"passed","scope":"Exact model results; no new experimental data",
            "input_sha256":{f"results/{n}.json":sha(ROOT/"results"/(n+".json")) for n in names},
            "source_sha256":sha(Path(__file__)),
            "output_sha256":{str(p.relative_to(ROOT)):sha(p) for p in paths}}
    (ROOT/"results/make_figure.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"status":"passed","panels":4}))

if __name__=="__main__":
    main()
