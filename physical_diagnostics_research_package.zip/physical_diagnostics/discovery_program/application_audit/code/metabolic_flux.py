#!/usr/bin/env python3
"""Exact channel-flux identification examples, with explicitly assumed inputs.

These are hypothetical reaction models and interval calculations. No experimental
metabolite data are generated or analyzed. Full observed-state Markov kinetics
and calibrated reaction-selective action factors are assumptions.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse
import json
import sympy as sp


def rational(value: object, name: str = "value") -> F:
    if type(value) is not F:
        raise TypeError(f"{name} must be an exact Fraction")
    return value


def log_bounds(x: F, terms: int = 96) -> tuple[F,F]:
    """Positive atanh-series enclosure for log(x), x >= 1."""
    rational(x)
    if x < 1 or type(terms) is not int or terms < 1:
        raise ValueError("Require x >= 1 and a positive integer term count")
    z=(x-1)/(x+1)
    lower=2*sum((z**(2*i+1)/(2*i+1) for i in range(terms)),F(0))
    upper=lower+2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    return lower,upper


@dataclass(frozen=True)
class ParallelChannels:
    a: F  # Channel 1: A -> B
    b: F  # Channel 1: B -> A
    c: F  # Channel 2: A -> B
    d: F  # Channel 2: B -> A

    def __post_init__(self):
        for name in ("a", "b", "c", "d"):
            if rational(getattr(self, name), name) <= 0:
                raise ValueError("This regular model requires strictly positive channel rates")

    @property
    def totals(self):
        return self.a + self.c, self.b + self.d

    @property
    def stationary(self):
        k, ell = self.totals
        return ell/(k+ell), k/(k+ell)

    @property
    def current(self):
        pa, pb = self.stationary
        return pa*self.a-pb*self.b

    @property
    def cycle_ratio(self):
        return self.a*self.d/(self.b*self.c)

    @property
    def entropy_rate(self):
        return sp.Rational(self.current) * sp.log(sp.Rational(self.cycle_ratio))

    @property
    def generator(self):
        k, ell = map(sp.Rational, self.totals)
        return sp.Matrix([[-k,k],[ell,-ell]])

    def selective(self, factor: F):
        rational(factor, "factor")
        if factor <= 0:
            raise ValueError("Use a strictly positive selective factor")
        return ParallelChannels(factor*self.a,factor*self.b,self.c,self.d)


def invert_selective(k0: F, ell0: F, k1: F, ell1: F, q: F) -> ParallelChannels:
    for name, x in (("k0",k0),("ell0",ell0),("k1",k1),("ell1",ell1),("q",q)):
        rational(x,name)
    if not 0 < q < 1:
        raise ValueError("Selective suppression requires 0<q<1")
    a, b = (k0-k1)/(1-q), (ell0-ell1)/(1-q)
    c, d = (k1-q*k0)/(1-q), (ell1-q*ell0)/(1-q)
    return ParallelChannels(a,b,c,d)


def infer_box(intervals: tuple[tuple[F,F], ...]) -> dict:
    """Sharp rate/current intervals for a five-coordinate rectangular input box.

    Each reconstructed rate, the current, and the cycle ratio are linear-fractional in each
    coordinate separately, with a positive denominator. Hence global extrema
    over the box occur at its vertices. All reconstructed rates must be positive
    throughout; vertex positivity suffices by the same argument.
    """
    if type(intervals) is not tuple or len(intervals) != 5:
        raise TypeError("Five intervals (k0, ell0, k1, ell1, q) required")
    for interval in intervals:
        if type(interval) is not tuple or len(interval) != 2:
            raise TypeError("Each interval must be a pair")
        lo, hi = interval
        rational(lo); rational(hi)
        if lo > hi:
            raise ValueError("Reversed interval")
    if any(lo <= 0 for lo,_ in intervals) or intervals[4][1] >= 1:
        raise ValueError("Positive rates and factors below one required")
    models = [invert_selective(*vertex) for vertex in product(*intervals)]
    intervals_out = {}
    for name in ("a","b","c","d","current","cycle_ratio"):
        values = [getattr(model,name) for model in models]
        intervals_out[name] = [str(min(values)),str(max(values))]
    entropy_bound=None
    current_low,current_high=map(F,intervals_out["current"])
    ratio_low,ratio_high=map(F,intervals_out["cycle_ratio"])
    if current_low > 0 and ratio_low > 1:
        lower=current_low*log_bounds(ratio_low)[0]
        upper=current_high*log_bounds(ratio_high)[1]
        # Display rounded outward with exact rational integer arithmetic.
        scale=10**9
        outward_low=F((lower*scale).numerator//(lower*scale).denominator,scale)
        outward_high=F(-(-(upper*scale).numerator//(upper*scale).denominator),scale)
        assert outward_low <= lower <= upper <= outward_high
        entropy_bound={"outward_rational_interval":[str(outward_low),str(outward_high)],
                       "exact_log_series_lower":str(lower),"exact_log_series_upper":str(upper),
                       "scope":"Conservative interval, not claimed sharp; units kB per model-time under channel-resolved local detailed balance"}
    return {"sharp_intervals":intervals_out,"vertices_checked":len(models),
            "entropy_production":entropy_bound,
            "proof":"Each output is coordinatewise linear-fractional with strictly positive denominator; extrema occur at vertices",
            "scope":"Conditional on simultaneous calibrated aggregate-rate and selective-factor bounds"}


def model_record(m: ParallelChannels) -> dict:
    return {"rates":[str(m.a),str(m.b),str(m.c),str(m.d)],
            "aggregate_rates":[str(x) for x in m.totals],
            "stationary":[str(x) for x in m.stationary],
            "channel1_current":str(m.current),"channel2_current":str(-m.current),
            "cycle_affinity":"log("+str(m.cycle_ratio)+")",
            "entropy_rate_in_kB_per_time":str(sp.simplify(m.entropy_rate))}


def main(output: Path) -> None:
    balanced = ParallelChannels(F(2),F(2),F(2),F(2))
    driven = ParallelChannels(F(3),F(1),F(1),F(3))
    reverse = ParallelChannels(F(1),F(3),F(3),F(1))
    assert balanced.generator == driven.generator == reverse.generator
    assert balanced.current == 0 and driven.current == 1 and reverse.current == -1
    assert sp.simplify(driven.entropy_rate-2*sp.log(3)) == 0
    assert driven.entropy_rate == reverse.entropy_rate
    # Uniform aggregation gives full path equality, not only stationary equality.
    R = sp.Matrix([[-2,2],[3,-3]])
    U = sp.diag(1,2)
    joints = [sp.kronecker_product(R,sp.eye(2))+sp.kronecker_product(U,m.generator)
              for m in (balanced,driven,reverse)]
    assert joints[0] == joints[1] == joints[2]

    # Positive rates can hide arbitrarily large affinity/EPR if no force bound
    # or thermodynamic channel calibration has been imposed.
    eps = sp.symbols("eps",positive=True)
    a,b,c,d = 4-eps,eps,eps,4-eps
    j = sp.simplify((a*d-b*c)/(a+b+c+d))
    assert j == 2-eps
    sigma = 2*(2-eps)*sp.log((4-eps)/eps)
    assert sp.limit(sigma,eps,0,dir="+") == sp.oo

    # Same cycle affinity need not identify magnitude when state energy is unknown.
    same_affinity = ParallelChannels(F(9,4),F(1,2),F(7,4),F(7,2))
    assert same_affinity.generator == driven.generator
    assert same_affinity.cycle_ratio == driven.cycle_ratio == 9
    assert same_affinity.current == F(7,8)

    # Genuine intervention: only channel 1 is scaled in both directions.
    q=F(1,2)
    perturbed = driven.selective(q)
    assert perturbed.totals == (F(5,2),F(7,2))
    recovered = invert_selective(*driven.totals,*perturbed.totals,q)
    assert recovered == driven
    W = sp.Matrix([[1,1],[sp.Rational(1,2),1]])
    assert W.det() == sp.Rational(1,2)
    assert W.inv() == sp.Matrix([[2,-2],[-1,2]])
    common = sp.Matrix([[1,1],[2,2],[3,3]])
    assert common.rank() == 1 and common*sp.Matrix([1,-1]) == sp.zeros(3,1)
    # Without knowing q, exact totals can yield another positive split/current.
    unknown_q_alternative = invert_selective(*driven.totals,*perturbed.totals,F(2,5))
    assert unknown_q_alternative != driven and unknown_q_alternative.current == F(5,6)

    box = infer_box(((F(399,100),F(401,100)),(F(399,100),F(401,100)),
                     (F(249,100),F(251,100)),(F(349,100),F(351,100)),
                     (F(49,100),F(51,100))))
    assert box["sharp_intervals"]["current"] == ["193/204","207/196"]
    entropy_lo,entropy_hi=map(F,box["entropy_production"]["outward_rational_interval"])
    ln3lo,ln3hi=log_bounds(F(3))
    assert entropy_lo < 2*ln3lo < 2*ln3hi < entropy_hi
    # Selected exact interior values check the sharp enclosure without replacing
    # the linear-fractional proof by a grid argument.
    for factor in (F(49,100),F(1,2),F(51,100)):
        fit=invert_selective(F(4),F(4),F(5,2),F(7,2),factor)
        assert F(193,204) <= fit.current <= F(207,196)

    # Thermodynamic information is genuine additional access. Known ratios can
    # already identify two channels without changing their kinetics.
    ratio_matrix=sp.Matrix([[3,sp.Rational(1,3)],[1,1]])
    backward=ratio_matrix.inv()*sp.Matrix([4,4])
    assert backward == sp.Matrix([1,3])
    # But with three known channel ratios, an observational fiber can remain.
    ratios=sp.diag(sp.Rational(1,3),1,3)
    back1=sp.Matrix([sp.Rational(3,2),2,sp.Rational(1,2)])
    back2=sp.Matrix([sp.Rational(3,4),3,sp.Rational(1,4)])
    forward1,forward2=ratios*back1,ratios*back2
    assert sum(back1)==sum(back2)==sum(forward1)==sum(forward2)==4
    currents1=(forward1-back1)/2
    currents2=(forward2-back2)/2
    entropy1=sum(currents1[i]*sp.log(ratios[i,i]) for i in range(3))
    entropy2=sum(currents2[i]*sp.log(ratios[i,i]) for i in range(3))
    assert sp.simplify(entropy1-sp.log(3))==0
    assert sp.simplify(entropy2-sp.log(3)/2)==0

    # A single scalar concentration/count can distinguish >=3 states. Its full
    # two-time law need not be reversible; scalar autocorrelation alone is even.
    Q=sp.Matrix([[-4,3,1],[1,-4,3],[3,1,-4]])
    scalar_pair_slope=(Q[0,1]-Q[1,0])/3
    assert scalar_pair_slope == sp.Rational(2,3)

    invalid=[]
    for name, call in {
        "inexact_rate":lambda:ParallelChannels(3.0,F(1),F(1),F(3)),
        "zero_reverse_rate":lambda:ParallelChannels(F(3),F(0),F(1),F(3)),
        "nonselective_inverse":lambda:invert_selective(F(4),F(4),F(4),F(4),F(1)),
        "unphysical_rate_fit":lambda:invert_selective(F(4),F(4),F(5),F(3),F(1,2)),
        "interval_crosses_singular_factor":lambda:infer_box(((F(4),F(4)),)*4+((F(1,2),F(1)),)),
    }.items():
        try:call()
        except (TypeError,ValueError):invalid.append(name)
        else:raise AssertionError(name)

    result={
        "status":"all_checks_passed","empirical_data":False,
        "evidence":"Exact hypothetical models, symbolic identities and rational interval bounds; not in-vivo flux measurements",
        "passive_path_equivalence":{"equilibrium":model_record(balanced),"forward_cycle":model_record(driven),
            "reverse_cycle":model_record(reverse),"same_full_observed_generator":True,
            "common_reversible_gate_joint_generator_identical":True,
            "unbounded_hidden_entropy_family":"(a,b,c,d)=(4-eps,eps,eps,4-eps), eps in (0,2); sigma=2(2-eps)log((4-eps)/eps) -> infinity without bounded force/channel premises",
            "same_affinity_alternative":model_record(same_affinity)},
        "selective_inference":{"factor":str(q),"fingerprint_matrix":str(W),"inverse":str(W.inv()),
            "perturbed_model":model_record(perturbed),"recovered_baseline":model_record(recovered),
            "baseline_current_formula":"(k0*ell1-ell0*k1)/((1-q)*(k0+ell0))",
            "calibrated_input_box":box,
            "factor_unknown_alternative":{"factor":"2/5","model":model_record(unknown_q_alternative)},
            "exact_factor_rate_error_amplification":{"channel1":"2 epsilon/(1-q)","channel2":"(1+q) epsilon/(1-q)"},
            "state_occupancy_and_current_preservation":False},
        "thermodynamic_prior_cases":{"two_known_ratios":{"ratios":["3","1/3"],"backward_rates":[str(x) for x in backward],
            "identified_without_intervention":True},"three_known_ratios":{"ratios":["1/3","1","3"],
            "model1_forward":[str(x) for x in forward1],"model1_backward":[str(x) for x in back1],
            "model2_forward":[str(x) for x in forward2],"model2_backward":[str(x) for x in back2],
            "entropy_rates":[str(entropy1),str(entropy2)],"same_aggregate_generator":True}},
        "single_scalar_reversibility_counterexample":{"state_readout":[0,1,2],"generator":str(Q),
            "pair_asymmetry_initial_slope":str(scalar_pair_slope),
            "scope":"Full scalar record law; not the ordinary scalar autocorrelation, which is even for any stationary real process",
            "binary_aggregate_extension":"See independent transfer-obstruction audit; singleton-state renewal theorem does not apply to general subsets"},
        "invalid_inputs_rejected":invalid,
        "versions":{"sympy":sp.__version__},"randomness":"none"}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":result["status"],"baseline_current":"1",
        "robust_current_interval":box["sharp_intervals"]["current"],"invalid_inputs_rejected":len(invalid),
        "empirical_data":False},indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,default=Path(__file__).resolve().parents[1]/"results/metabolic_flux.json")
    main(parser.parse_args().output)
