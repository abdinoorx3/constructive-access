#!/usr/bin/env python3
"""Exact finite-menu Ramsey sign sensing with dephasing and fixed nuisance.

A hypothetical effective binary sensor model, not NV experimental data.
The standard-library Bellman solver minimizes 0-1 field-SIGN Bayes risk.
It does NOT maximize Fisher information or optimize arbitrary pulse controls.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import atan2, exp, log, pi, sqrt
from pathlib import Path
import json


@dataclass(frozen=True)
class Hypothesis:
    sign: int
    bias: F


@dataclass(frozen=True)
class Action:
    name: str
    duration: int
    overhead: int
    cosine_phase: int
    sine_phase: int

    @property
    def cost(self) -> int:
        return self.duration + self.overhead


def phase_power(m: int) -> tuple[F, F]:
    """cos(m theta), sin(m theta), where cos theta=4/5, sin theta=3/5."""
    if m < 0:
        raise ValueError("duration must be nonnegative")
    c, s = F(1), F(0)
    for _ in range(m):
        c, s = (4*c - 3*s)/5, (3*c + 4*s)/5
    assert c*c+s*s == 1
    return c, s


class RamseyModel:
    def __init__(self, visibility: F=F(4,5), retention: F=F(4,5), overhead: int=2,
                 durations: tuple[int,...]=(1,2,3,4), biases: tuple[F,...]=(F(-1,20),F(1,20))):
        if any(not isinstance(x,(int,F)) or isinstance(x,bool) for x in (visibility,retention,*biases)):
            raise TypeError("channel parameters must be exact integers or fractions.Fraction")
        if type(overhead) is not int or not durations or any(type(m) is not int or m<=0 for m in durations):
            raise ValueError("use nonnegative integer overhead and positive integer sensing durations")
        if not biases:
            raise ValueError("the fixed nuisance grid must be nonempty")
        if not 0 <= visibility <= 1 or not 0 <= retention <= 1 or overhead < 0:
            raise ValueError("inadmissible contrast or cost")
        self.visibility = visibility
        self.retention = retention
        self.hypotheses = tuple(Hypothesis(sign,bias) for sign in (-1,1) for bias in biases)
        self.actions = tuple(Action(f"{phase}{m}",m,overhead,c,s)
                             for m in durations for phase,c,s in
                             (("X",1,0),("-X",-1,0),("Y",0,1),("-Y",0,-1)))
        self.probabilities = tuple(tuple(self.probability(h,a) for h in self.hypotheses)
                                   for a in self.actions)
        assert all(0 < p < 1 for row in self.probabilities for p in row)
        # Even before dephasing, E_1=(1/2+b)I+(C/2)*Pauli_axis is a POVM effect.
        assert all(0 <= F(1,2)+b-visibility/2 and F(1,2)+b+visibility/2 <= 1 for b in biases)

    def probability(self,h:Hypothesis,a:Action) -> F:
        c,s=phase_power(a.duration)
        # Define Y as the positive-sine readout quadrature. This fixes phase sign.
        signal=c*a.cosine_phase+h.sign*s*a.sine_phase
        return F(1,2)+h.bias+self.visibility*self.retention**a.duration*signal/2

    def update(self,w:tuple[F,...], ai:int,y:int) -> tuple[F,...]:
        return tuple(z*(p if y else 1-p) for z,p in zip(w,self.probabilities[ai]))

    def loss(self,w:tuple[F,...]) -> F:
        negative=sum((z for z,h in zip(w,self.hypotheses) if h.sign<0),F(0))
        positive=sum(w,F(0))-negative
        return min(negative,positive)

    def prior(self) -> tuple[F,...]:
        return (F(1,len(self.hypotheses)),)*len(self.hypotheses)

    def fisher_known_bias(self,a:Action,bias:F=F(0)) -> F:
        """Local scalar FI in x=gamma*B*tau at +theta, with bias treated known."""
        c,s=phase_power(a.duration)
        amplitude=self.visibility*self.retention**a.duration/2
        p=F(1,2)+bias+amplitude*(c*a.cosine_phase+s*a.sine_phase)
        derivative=amplitude*a.duration*(-s*a.cosine_phase+c*a.sine_phase)
        return derivative*derivative/(p*(1-p))


def solve_bayes(model:RamseyModel,budget:int) -> dict:
    if type(budget) is not int or budget<0:
        raise ValueError("budget must be a nonnegative integer")
    decisions={}
    @lru_cache(None)
    def value(w:tuple[F,...],remaining:int) -> F:
        best=model.loss(w)
        choice=None
        for ai,a in enumerate(model.actions):
            if a.cost <= remaining:
                trial=sum((value(model.update(w,ai,y),remaining-a.cost) for y in (0,1)),F(0))
                if trial < best:
                    best,choice=trial,ai
        decisions[w,remaining]=choice
        return best
    risk=value(model.prior(),budget)
    def export(w,remaining):
        ai=decisions[w,remaining]
        if ai is None:
            masses={s:sum(z for z,h in zip(w,model.hypotheses) if h.sign==s) for s in (-1,1)}
            return {"stop":True,"declare_sign":1 if masses[1]>=masses[-1] else -1}
        a=model.actions[ai]
        return {"action":a.name,"cost":a.cost,"branches":{str(y):export(model.update(w,ai,y),remaining-a.cost) for y in (0,1)}}
    policy=export(model.prior(),budget)
    # Independently enumerate complete leaves, evaluating likelihood and error.
    def evaluate(node,w,spent):
        if node.get("stop"):
            wrong=sum((z for z,h in zip(w,model.hypotheses) if h.sign != node["declare_sign"]),F(0))
            return wrong,sum(w,F(0))*spent,spent,1
        ai=next(i for i,a in enumerate(model.actions) if a.name==node["action"])
        results=[evaluate(node["branches"][str(y)],model.update(w,ai,y),spent+model.actions[ai].cost) for y in (0,1)]
        return sum(r[0] for r in results),sum(r[1] for r in results),max(r[2] for r in results),sum(r[3] for r in results)
    verified,expected,maxcost,leaves=evaluate(policy,model.prior(),0)
    assert verified==risk and maxcost<=budget
    return {"risk":risk,"policy":policy,"expected_cost":expected,"maximum_cost":maxcost,
            "leaf_count":leaves,"bellman_states":value.cache_info().currsize}


def plan_risk(model:RamseyModel,plan:tuple[int,...]) -> F:
    total=F(0)
    for ys in product((0,1),repeat=len(plan)):
        w=model.prior()
        for ai,y in zip(plan,ys):
            w=model.update(w,ai,y)
        total+=model.loss(w)
    return total


def best_nonadaptive(model:RamseyModel,budget:int) -> dict:
    # Under the fixed nuisance and independent preparations, scalar likelihoods
    # commute. Enumerate ALL action multisets, not a selected heuristic baseline.
    best=F(1,2)
    bestplan=()
    count=0
    def search(prefix:tuple[int,...],start:int,remaining:int):
        nonlocal best,bestplan,count
        risk=plan_risk(model,prefix)
        count+=1
        if risk<best or (risk==best and sum(model.actions[i].cost for i in prefix)<sum(model.actions[i].cost for i in bestplan)):
            best,bestplan=risk,prefix
        for ai in range(start,len(model.actions)):
            a=model.actions[ai]
            if a.cost<=remaining:
                search(prefix+(ai,),ai,remaining-a.cost)
    search((),0,budget)
    return {"risk":best,"plan":[model.actions[i].name for i in bestplan],
            "cost":sum(model.actions[i].cost for i in bestplan),"all_multisets_checked":count}


def fisher_greedy_plan(model:RamseyModel,budget:int) -> dict:
    plan=[]
    remaining=budget
    while any(a.cost<=remaining for a in model.actions):
        ai=max((i for i,a in enumerate(model.actions) if a.cost<=remaining),
               key=lambda i:model.fisher_known_bias(model.actions[i])/model.actions[i].cost)
        plan.append(ai)
        remaining-=model.actions[ai].cost
    return {"plan":[model.actions[i].name for i in plan],"risk":plan_risk(model,tuple(plan)),
            "cost":budget-remaining,"criterion":"Greedy scalar local Fisher information per total time; bias assumed known at zero for the criterion."}


def exhaustive_two_round_check(model:RamseyModel,budget:int=6) -> dict:
    # Independent enumeration of all deterministic decision trees with at most
    # two observations; cost>=3 makes this exhaustive for budget6.
    best=model.loss(model.prior())
    trees=1
    for ai,a in enumerate(model.actions):
        if a.cost>budget:
            continue
        remaining=budget-a.cost
        next_choices=[None]+[j for j,b in enumerate(model.actions) if b.cost<=remaining]
        for left,right in product(next_choices,repeat=2):
            risk=F(0)
            for y,aj in ((0,left),(1,right)):
                w=model.update(model.prior(),ai,y)
                if aj is None:
                    risk+=model.loss(w)
                else:
                    risk+=sum((model.loss(model.update(w,aj,z)) for z in (0,1)),F(0))
            best=min(best,risk)
            trees+=1
    bellman=solve_bayes(model,budget)["risk"]
    assert best==bellman
    return {"budget":budget,"all_deterministic_trees":trees,"exact_risk":str(best)}


def nuisance_and_noise_checks(model:RamseyModel) -> dict:
    # One quadrature action cannot distinguish sign from an unrestricted additive
    # nuisance: p=.5+b+sign*d; taking b_- = b_+ + 2d gives identical channels.
    a=next(a for a in model.actions if a.name=="Y1")
    d=model.visibility*model.retention*F(3,5)/2
    # Use a separately declared lower-contrast sensor so the larger nuisance
    # interval remains a physically admissible POVM for EVERY qubit state.
    weak_visibility=F(3,10)
    weak_d=weak_visibility*model.retention*F(3,5)/2
    assert F(1,2)-weak_d+weak_d == F(1,2)+weak_d-weak_d
    assert 0 <= F(1,2)-weak_d-weak_visibility/2
    assert F(1,2)+weak_d+weak_visibility/2 <= 1
    # Fixed nuisance must be integrated AFTER multiplying record likelihoods.
    ai=next(i for i,a in enumerate(model.actions) if a.name=="Y1")
    plus_indices=[i for i,h in enumerate(model.hypotheses) if h.sign==1]
    probs=[model.probabilities[ai][i] for i in plus_indices]
    fixed=sum(p*p for p in probs)/len(probs)
    redrawn=(sum(probs)/len(probs))**2
    assert fixed != redrawn
    rare_gap=F(1,100)
    rare_samples=0
    while F(1,2)*(1-rare_gap)**rare_samples > F(1,10):
        rare_samples+=1
    assert rare_samples==161
    # If eta uncertainty allows exact cancellation, repetition cannot identify
    # two equal output laws. Alternating quadrature sign removes an additive
    # bias in the expected DIFFERENCE under a constant-bias assumption.
    return {"single_quadrature_signal_amplitude":str(d),
            "admissible_lower_contrast_overlap_counterexample":{"visibility":str(weak_visibility),
                "bias_radius":str(weak_d),"opposite_sign_laws":"Both Bernoulli(1/2) at the Y1 action."},
            "fixed_nuisance_two_ones":str(fixed),"per_shot_redraw_two_ones":str(redrawn),
            "redraw_error":str(fixed-redrawn),
            "echo_dc_phase":0,"echo_same_axis_static_noise_phase":0,
            "white_markov_dephasing_changes_under_ideal_sign_modulation":False,
            "conditional_dephasing_retention":str(model.retention),
            "rare_event_counterexample":{"p0":"0","p1":"1/100","equal_prior_error":"(1/2)*(99/100)^n",
                                         "minimum_n_for_error_at_most_0.1":rare_samples,
                                         "scaling":"Order 1/gap for fixed error; inverse-gap-squared is not universal."}}


def stringify(x):
    if isinstance(x,F):
        return {"exact":str(x),"float":float(x)}
    if isinstance(x,dict):
        return {str(k):stringify(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):
        return [stringify(v) for v in x]
    return x


def main():
    model=RamseyModel()
    budget=12
    bayes=solve_bayes(model,budget)
    fixed=best_nonadaptive(model,budget)
    fisher=fisher_greedy_plan(model,budget)
    assert bayes["risk"]<=fixed["risk"]<fisher["risk"]==F(1,2)
    x3=next(a for a in model.actions if a.name=="X3")
    y2=next(a for a in model.actions if a.name=="Y2")
    assert model.fisher_known_bias(x3)/x3.cost > model.fisher_known_bias(y2)/y2.cost
    for a in model.actions:
        if a.sine_phase==0:
            assert all(model.probability(Hypothesis(-1,b),a)==model.probability(Hypothesis(1,b),a) for b in (F(-1,20),F(1,20)))
    tau=100e-6
    physical={"hypothetical_not_measured":True,"base_time_seconds":tau,"overhead_seconds":2*tau,
              "coherence_time_seconds":-tau/log(float(model.retention)),
              "field_magnitude_tesla":atan2(3,4)/(2*pi*28e9*tau),
              "total_budget_seconds":budget*tau,
              "readout_visibility":float(model.visibility),
              "note":"Effective two-level Ramsey model; no assertion these parameters jointly describe a measured NV apparatus."}
    coherence=physical["coherence_time_seconds"]
    overhead=physical["overhead_seconds"]
    fisher_time=(coherence-2*overhead+sqrt((coherence-2*overhead)**2+16*coherence*overhead))/4
    physical["optimal_continuous_local_fisher_sensing_seconds_under_model"]=fisher_time
    physical["continuous_local_fisher_phase_rate_max_seconds"]=(float(model.visibility)**2*fisher_time**2
                                                               *exp(-2*fisher_time/coherence)/(fisher_time+overhead))
    extension_budget=15
    extension_adaptive=solve_bayes(model,extension_budget)
    extension_fixed=best_nonadaptive(model,extension_budget)
    assert extension_fixed["risk"]-extension_adaptive["risk"]==F(6,3125)
    actions=[]
    for i,a in enumerate(model.actions):
        actions.append({"name":a.name,"duration":a.duration,"overhead":a.overhead,"cost":a.cost,
                        "visibility_after_dephasing":model.visibility*model.retention**a.duration,
                        "probability_by_hypothesis":model.probabilities[i],
                        "local_fisher_known_bias0":model.fisher_known_bias(a),
                        "local_fisher_per_total_time":model.fisher_known_bias(a)/a.cost})
    output={"status":"Exact hypothetical finite-menu application of established Bayesian design; not empirical NV validation or universal control optimality.",
            "hypotheses":[{"sign":h.sign,"fixed_bias":h.bias} for h in model.hypotheses],
            "prior":model.prior(),"budget_ticks":budget,"physical_mapping":physical,"actions":actions,
            "optimal_adaptive_bayes":bayes,"optimal_nonadaptive":fixed,"local_fisher_greedy":fisher,
            "adaptive_absolute_risk_improvement":fixed["risk"]-bayes["risk"],
            "budget12_early_stop_interpretation":"Same risk as fixed Y2,Y2,-Y2; after agreeing first two outcomes the final readout cannot change the Bayes decision. Expected-time saving is optional stopping, not a feedback-design risk advantage.",
            "larger_budget_extension":{"budget_ticks":extension_budget,"adaptive":extension_adaptive,
                                       "best_nonadaptive":extension_fixed,
                                       "absolute_improvement":extension_fixed["risk"]-extension_adaptive["risk"]},
            "exhaustive_policy_check":exhaustive_two_round_check(model),
            "nuisance_and_noise_controls":nuisance_and_noise_checks(model),
            "limitations":["Four fixed hypotheses and sixteen declared action channels, not a continuous nuisance guarantee.",
                           "Timing overhead is included; energy, heating, drift, feedback latency and readout memory require separate calibrated models.",
                           "Local Fisher information is a different objective from sign misclassification risk.",
                           "Controls that refocus a DC field cancel its signal along with same-axis quasistatic noise.",
                           "No independent experimental data, biological-sensing advantage or universal inverse-gap-squared law is established."]}
    destination=Path(__file__).resolve().parents[1]/"results"/"nv_sensing.json"
    destination.write_text(json.dumps(stringify(output),indent=2)+"\n")
    print(json.dumps({"checks":"PASS","bayes":float(bayes["risk"]),"best_nonadaptive":float(fixed["risk"]),
                      "fisher_greedy":float(fisher["risk"]),"states":bayes["bellman_states"],
                      "first_action":bayes["policy"].get("action"),"output":str(destination)},indent=2))


if __name__=="__main__":
    main()
